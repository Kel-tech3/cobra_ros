"""Webots controller of the CobraFlex robot in webots/protos: drive + all sensors over one link.

Wire format (see src/cobra_flex/cobra_flex/protocol.py):
commands  UDP :5555  "<2f" (v m/s, w rad/s); the robot stops if no command for CMD_TIMEOUT
telemetry TCP or UDP to TELEMETRY_HOST:5600 - WBTG (odometry, gyro, lidar), WBTL (lidar geometry),
          WBTD (depth), WBTR (rgb)

- v and w are real speeds (wheel rad/s = v / radius), like {"T":13} on the real robot;
- LiDAR rays are sent in ROS order: from -fov/2 (right) counterclockwise;
- gyro rates are in the robot frame (x forward, y left, z up);
- the simulation keeps running while the ROS side is not connected;
- every 5 s the true pose (GPS, InertialUnit) is printed to the Webots console.

Environment: CMD_LISTEN_PORT, TELEMETRY_PROTO (tcp|udp), TELEMETRY_HOST, TELEMETRY_PORT,
CMD_TIMEOUT, MAX_LINEAR, MAX_ANGULAR, MAX_LINEAR_ACC, MAX_ANGULAR_ACC, TEL_EVERY, LIDAR_REVERSE, ODOM_TRACK,
DEPTH_ENABLE, DEPTH_EVERY, DEPTH_DOWNSAMPLE, RGB_ENABLE, RGB_EVERY, RGB_DOWNSAMPLE, MAX_DGRAM,
SNAPSHOT (file name: save one RGB camera image after SNAPSHOT_STEP steps, for debugging)
"""
import itertools
import math
import os
import socket
import struct
import time
from array import array

from controller import Robot

E = os.environ.get
CMD_PORT = int(E("CMD_LISTEN_PORT", "5555"))
PROTO = E("TELEMETRY_PROTO", "tcp").lower()
TEL_ADDR = (E("TELEMETRY_HOST", "127.0.0.1"), int(E("TELEMETRY_PORT", "5600")))
CMD_TIMEOUT = float(E("CMD_TIMEOUT", "0.5"))
MAX_LINEAR = float(E("MAX_LINEAR", "0.5"))
MAX_ANGULAR = float(E("MAX_ANGULAR", "2.0"))
MAX_LINEAR_ACC = float(E("MAX_LINEAR_ACC", "1.0"))
MAX_ANGULAR_ACC = float(E("MAX_ANGULAR_ACC", "4.0"))
TEL_EVERY = int(E("TEL_EVERY", "2"))
DEPTH_ENABLE = E("DEPTH_ENABLE", "1") == "1"
DEPTH_EVERY = int(E("DEPTH_EVERY", "4"))
DEPTH_DS = int(E("DEPTH_DOWNSAMPLE", "2"))
RGB_ENABLE = E("RGB_ENABLE", "0") == "1"
RGB_EVERY = int(E("RGB_EVERY", "8"))
RGB_DS = int(E("RGB_DOWNSAMPLE", "2"))
MAX_DGRAM = int(E("MAX_DGRAM", "1200"))
LIDAR_REVERSE = E("LIDAR_REVERSE", "1") == "1"  # Webots gives rays from the left, ROS wants from the right
SNAPSHOT = E("SNAPSHOT", "")
SNAPSHOT_STEP = int(E("SNAPSHOT_STEP", "100"))

WHEEL_RADIUS = 0.037  # CobraFlex.proto wheel cylinder
TRACK = 0.164         # wheel anchors at y = +-0.082, used for driving like the robot firmware
# skid steering slips when turning: odometry needs a wider "effective" track, measured in this world
# (the same calibration as odom_track_width of cobra_base on the real robot)
ODOM_TRACK = float(E("ODOM_TRACK", "0.254"))
GYRO_IN_ROBOT_FRAME = 1  # WBTL flag


class Link:
    """Telemetry sender: TCP with length prefix (reconnects in the background) or chunked UDP."""

    def __init__(self):
        self.sock = None
        self.next_try = 0.0
        self.msg_id = itertools.count()
        if PROTO == "udp":
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def connected(self):
        if self.sock is not None:
            return True
        now = time.monotonic()
        if now < self.next_try:
            return False
        self.next_try = now + 1.0
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.2)
        try:
            s.connect(TEL_ADDR)
        except OSError:
            s.close()
            return False
        s.settimeout(None)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.sock = s
        print(f"[cobra_udp] telemetry connected to {TEL_ADDR[0]}:{TEL_ADDR[1]}", flush=True)
        return True

    def send(self, payload):
        if not self.connected():
            return
        try:
            if PROTO != "udp":
                self.sock.sendall(struct.pack("<I", len(payload)) + payload)
            elif len(payload) <= MAX_DGRAM:
                self.sock.sendto(payload, TEL_ADDR)
            else:
                mid = next(self.msg_id) & 0xFFFFFFFF
                size = MAX_DGRAM - 16
                count = (len(payload) + size - 1) // size
                for i in range(count):
                    head = b"CHNK" + struct.pack("<IIHH", mid, len(payload), i, count)
                    self.sock.sendto(head + payload[i * size:(i + 1) * size], TEL_ADDR)
        except OSError:
            if PROTO != "udp":
                self.sock.close()
                self.sock = None
                print("[cobra_udp] telemetry disconnected, retrying", flush=True)


def device(robot, name):
    try:
        return robot.getDevice(name)
    except Exception:
        return None


def step_toward(cur, target, max_delta):
    return cur + max(-max_delta, min(max_delta, target - cur))


def main():
    robot = Robot()
    ts = int(robot.getBasicTimeStep())
    dt = ts / 1000.0

    left = [device(robot, n) for n in ("left_front_motor", "left_rear_motor")]
    right = [device(robot, n) for n in ("right_front_motor", "right_rear_motor")]
    for m in left + right:
        m.setPosition(float("inf"))
        m.setVelocity(0.0)
    wheel_max = min(m.getMaxVelocity() for m in left + right)
    enc_l = [device(robot, n) for n in ("left_front_encoder", "left_rear_encoder")]
    enc_r = [device(robot, n) for n in ("right_front_encoder", "right_rear_encoder")]
    for e in enc_l + enc_r:
        e.enable(ts)

    lidar = device(robot, "lidar")
    if lidar:
        lidar.enable(ts)
    gyro = device(robot, "gyro")
    if gyro:
        gyro.enable(ts)
    depth = device(robot, "depth") if DEPTH_ENABLE else None
    if depth:
        depth.enable(ts)
    rgb = device(robot, "rgb") if (RGB_ENABLE or SNAPSHOT) else None
    if rgb:
        rgb.enable(ts)
    gps, imu = device(robot, "gps"), device(robot, "imu")
    for dev in (gps, imu):
        if dev:
            dev.enable(ts)
    lidar_info = b""
    if lidar:
        rmin, rmax = lidar.getMinRange(), lidar.getMaxRange()
        lidar_info = b"WBTL" + struct.pack("<fffI", lidar.getFov(), rmin, rmax, GYRO_IN_ROBOT_FRAME)
    print(f"[cobra_udp] lidar={bool(lidar)} gyro={bool(gyro)} depth={bool(depth)} rgb={bool(rgb)} "
          f"cmd udp:{CMD_PORT} telemetry {PROTO}://{TEL_ADDR[0]}:{TEL_ADDR[1]}", flush=True)

    cmd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    cmd.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    cmd.bind(("0.0.0.0", CMD_PORT))
    cmd.setblocking(False)
    link = Link()

    target_v = target_w = v = w = 0.0
    last_cmd = 0.0
    x = y = th = 0.0
    prev = None
    step = 0

    while robot.step(ts) != -1:
        step += 1
        # --- commands: keep only the newest packet ---
        while True:
            try:
                data, _ = cmd.recvfrom(64)
            except (BlockingIOError, OSError):
                break
            if len(data) >= 8:
                target_v, target_w = struct.unpack("<2f", data[:8])
                last_cmd = time.monotonic()
        if time.monotonic() - last_cmd > CMD_TIMEOUT:
            target_v = target_w = 0.0
        target_v = max(-MAX_LINEAR, min(MAX_LINEAR, target_v))
        target_w = max(-MAX_ANGULAR, min(MAX_ANGULAR, target_w))
        v = step_toward(v, target_v, MAX_LINEAR_ACC * dt)
        w = step_toward(w, target_w, MAX_ANGULAR_ACC * dt)
        wl = (v - w * TRACK / 2.0) / WHEEL_RADIUS
        wr = (v + w * TRACK / 2.0) / WHEEL_RADIUS
        k = min(1.0, wheel_max / max(abs(wl), abs(wr), 1e-9))
        for m in left:
            m.setVelocity(wl * k)
        for m in right:
            m.setVelocity(wr * k)

        # --- wheel odometry ---
        cur = (sum(e.getValue() for e in enc_l) / 2.0, sum(e.getValue() for e in enc_r) / 2.0)
        if prev is not None and not any(math.isnan(c) for c in cur):
            dl = (cur[0] - prev[0]) * WHEEL_RADIUS
            dr = (cur[1] - prev[1]) * WHEEL_RADIUS
            ds, dth = (dl + dr) / 2.0, (dr - dl) / ODOM_TRACK
            x += ds * math.cos(th + dth / 2.0)
            y += ds * math.sin(th + dth / 2.0)
            th += dth
        prev = cur

        # --- telemetry ---
        if lidar_info and step % 60 == 1:  # about once a second: LiDAR geometry for the bridge
            link.send(lidar_info)
        if step % TEL_EVERY == 0:
            g = gyro.getValues() if gyro else (0.0, 0.0, 0.0)
            ranges = []
            if lidar:
                ranges = [r if rmin < r < rmax else rmax for r in lidar.getRangeImage()]
                if LIDAR_REVERSE:
                    ranges.reverse()
            payload = b"WBTG" + struct.pack("<9fI", x, y, th, v, 0.0, w, g[0], g[1], g[2], len(ranges))
            if ranges:
                payload += struct.pack(f"<{len(ranges)}f", *ranges)
            link.send(payload)

        if depth and step % DEPTH_EVERY == 0:
            wd, hd = depth.getWidth(), depth.getHeight()
            img = depth.getRangeImage()
            mn, mx = depth.getMinRange(), depth.getMaxRange()
            mm = array("H")
            for row in range(0, hd, DEPTH_DS):
                base = row * wd
                mm.extend(int(z * 1000.0 + 0.5) if mn < z < mx else 0 for z in img[base:base + wd:DEPTH_DS])
            dw, dh = (wd + DEPTH_DS - 1) // DEPTH_DS, (hd + DEPTH_DS - 1) // DEPTH_DS
            link.send(b"WBTD" + struct.pack("<HHiff", dw, dh, DEPTH_DS, mn, mx) + mm.tobytes())

        if rgb and step % RGB_EVERY == 0:
            wc, hc = rgb.getWidth(), rgb.getHeight()
            raw = rgb.getImage()
            out = bytearray()
            for row in range(0, hc, RGB_DS):
                line = raw[row * wc * 4:(row + 1) * wc * 4]
                for col in range(0, wc, RGB_DS):
                    out += line[col * 4:col * 4 + 4]
            dw, dh = (wc + RGB_DS - 1) // RGB_DS, (hc + RGB_DS - 1) // RGB_DS
            link.send(b"WBTR" + struct.pack("<HHi", dw, dh, RGB_DS) + bytes(out))

        if SNAPSHOT and rgb and step == SNAPSHOT_STEP:
            rgb.saveImage(SNAPSHOT, 90)
            print(f"[cobra_udp] saved {SNAPSHOT}", flush=True)

        if gps and step % max(1, int(5.0 / dt)) == 0:
            px, py, pz = gps.getValues()
            yaw = imu.getRollPitchYaw()[2] if imu else float("nan")
            print(f"[cobra_udp] pose x={px:.2f} y={py:.2f} z={pz:.2f} yaw={math.degrees(yaw):.0f} deg; "
                  f"odom x={x:.2f} y={y:.2f} yaw={math.degrees(th):.0f} deg", flush=True)


if __name__ == "__main__":
    main()
