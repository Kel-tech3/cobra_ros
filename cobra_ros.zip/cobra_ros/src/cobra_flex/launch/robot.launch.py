"""Real Cobra Flex on the Raspberry Pi.

ros2 launch cobra_flex robot.launch.py                          # chassis driver + sensor TFs
ros2 launch cobra_flex robot.launch.py slam:=true               # + slam_toolbox
ros2 launch cobra_flex robot.launch.py port:=/dev/ttyACM0

Start the LiDAR and depth camera drivers separately (their own launch files); they must publish
/scan in frame "laser" and depth in "camera_depth_optical_frame" (or change the frame arguments).
Measure the sensor positions on your robot and pass them as arguments.
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration as L
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def static_tf(parent, child, x="0", y="0", z="0", roll="0", pitch="0", yaw="0"):
    args = ["--x", x, "--y", y, "--z", z, "--roll", roll, "--pitch", pitch, "--yaw", yaw,
            "--frame-id", parent, "--child-frame-id", child]
    return Node(package="tf2_ros", executable="static_transform_publisher",
                name=f"tf_{child}", arguments=args, output="log")


def generate_launch_description():
    share = get_package_share_directory("cobra_flex")
    args = {
        "port": ("/dev/serial/by-id/usb-1a86_USB_Single_Serial_*", "chassis serial port, glob allowed"),
        "odom_track_width": ("0.159", "calibrate: spin 360 deg in place"),
        "slam": ("false", "start slam_toolbox"),
        "publish_tf": ("true", "false when robot_localization publishes odom TF"),
        "laser_frame": ("laser", "frame of your LiDAR driver"),
        "laser_x": ("0.0", "LiDAR position from the robot centre, m (x forward, z up)"),
        "laser_z": ("0.15", ""),
        "laser_yaw": ("0.0", "rad; many LiDARs are mounted with the cable backwards: 3.1416"),
        "camera_frame": ("camera_link", "base frame of your camera driver"),
        "camera_x": ("0.10", ""),
        "camera_z": ("0.12", ""),
        "camera_pitch": ("0.0", "rad, positive = looking down"),
    }
    decl = [DeclareLaunchArgument(k, default_value=v, description=d) for k, (v, d) in args.items()]
    return LaunchDescription(decl + [
        Node(package="cobra_flex", executable="cobra_base", output="screen",
             parameters=[{"port": L("port"),
                          "odom_track_width": ParameterValue(L("odom_track_width"), value_type=float),
                          "publish_tf": ParameterValue(L("publish_tf"), value_type=bool)}]),
        static_tf("base_footprint", "base_link"),
        Node(package="tf2_ros", executable="static_transform_publisher", name="tf_laser",
             arguments=["--x", L("laser_x"), "--z", L("laser_z"), "--yaw", L("laser_yaw"),
                        "--frame-id", "base_link", "--child-frame-id", L("laser_frame")]),
        Node(package="tf2_ros", executable="static_transform_publisher", name="tf_camera",
             arguments=["--x", L("camera_x"), "--z", L("camera_z"), "--pitch", L("camera_pitch"),
                        "--frame-id", "base_link", "--child-frame-id", L("camera_frame")]),
        Node(package="slam_toolbox", executable="async_slam_toolbox_node", name="slam_toolbox",
             output="screen", condition=IfCondition(L("slam")),
             parameters=[os.path.join(share, "config", "slam_toolbox.yaml")]),
    ])
