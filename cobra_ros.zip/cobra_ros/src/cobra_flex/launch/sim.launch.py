"""Webots (worlds in webots/worlds) <-> ROS 2.

ros2 launch cobra_flex sim.launch.py                 # bridge + sensor TFs
ros2 launch cobra_flex sim.launch.py slam:=true      # + slam_toolbox (map on /map)
ros2 launch cobra_flex sim.launch.py proto:=udp      # controller sending over UDP
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration as L
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def static_tf(parent, child, x=0.0, y=0.0, z=0.0, roll=0.0, pitch=0.0, yaw=0.0):
    args = ["--x", str(x), "--y", str(y), "--z", str(z),
            "--roll", str(roll), "--pitch", str(pitch), "--yaw", str(yaw),
            "--frame-id", parent, "--child-frame-id", child]
    return Node(package="tf2_ros", executable="static_transform_publisher",
                name=f"tf_{child}", arguments=args, output="log")


def generate_launch_description():
    share = get_package_share_directory("cobra_flex")
    optical = dict(roll=-1.5708, yaw=-1.5708)  # camera_link (x forward) -> optical (z forward)
    return LaunchDescription([
        DeclareLaunchArgument("slam", default_value="false"),
        DeclareLaunchArgument("publish_tf", default_value="true",
                              description="false when robot_localization publishes odom TF"),
        DeclareLaunchArgument("proto", default_value="tcp", description="tcp | udp"),
        DeclareLaunchArgument("lidar_reverse", default_value="false",
                              description="true if obstacles on the left appear on the right in RViz"),
        DeclareLaunchArgument("cmd_host", default_value="127.0.0.1",
                              description="where Webots runs; host.docker.internal from Docker Desktop"),
        Node(package="cobra_flex", executable="webots_bridge", output="screen",
             parameters=[{"proto": L("proto"), "cmd_host": L("cmd_host"),
                          "publish_tf": ParameterValue(L("publish_tf"), value_type=bool),
                          "lidar_reverse": ParameterValue(L("lidar_reverse"), value_type=bool)}]),
        # sensor positions of webots/protos/CobraFlex.proto
        static_tf("base_footprint", "base_link"),
        static_tf("base_link", "laser", z=0.13),
        static_tf("base_link", "camera_link", x=-0.10, z=0.30, pitch=0.5854),
        static_tf("camera_link", "camera_depth_optical_frame", **optical),
        static_tf("camera_link", "camera_color_optical_frame", **optical),
        Node(package="slam_toolbox", executable="async_slam_toolbox_node", name="slam_toolbox",
             output="screen", condition=IfCondition(L("slam")),
             parameters=[os.path.join(share, "config", "slam_toolbox.yaml")]),
    ])
