"""ROS 2 driver for the real Cobra Flex chassis (ESP32 driver board, JSON over serial).

Subscribes: /cmd_vel (geometry_msgs/Twist) -> {"T":13,"X":v,"Z":w}
Publishes:  /odom + TF odom->base_footprint (from wheel distances odl/odr),
            /battery (sensor_msgs/BatteryState)

The factory firmware sends {"T":1001,"M1".."M4","odl","odr","v"}: odl/odr = wheel distance in cm,
v = battery voltage x 100. It has no IMU output. It stops the motors by itself if no drive command
arrives for 3 s; this node sends a stop as soon as /cmd_vel is older than cmd_timeout.
"""
import glob
import json
import math
import threading
import time

import rclpy
import serial
from geometry_msgs.msg import Twist
from rclpy.node import Node
from sensor_msgs.msg import BatteryState
from tf2_ros import TransformBroadcaster

from cobra_flex.common import CmdVelGate, OdomPublisher


class CobraBase(Node):
    def __init__(self):
        super().__init__("cobra_base")
        p = self.declare_parameter
        p("port", "/dev/serial/by-id/usb-1a86_USB_Single_Serial_*")  # glob allowed
        p("baud", 115200)
        p("cmd_rate", 20.0)
        p("cmd_timeout", 0.5)
        p("max_linear", 0.5)
        p("max_angular", 2.0)
        # distance between left and right wheels as seen by odometry; a skid-steer robot turns
        # "wider" than its geometry, calibrate: spin 360 deg in place and adjust until /odom says 360
        p("odom_track_width", 0.159)
        p("odom_frame", "odom")
        p("base_frame", "base_footprint")
        p("publish_tf", True)
        g = lambda name: self.get_parameter(name).value  # noqa: E731

        self.track = g("odom_track_width")
        self.gate = CmdVelGate(g("cmd_timeout"), g("max_linear"), g("max_angular"))
        self.create_subscription(Twist, "cmd_vel", self.gate.update, 10)
        self.odom = OdomPublisher(self, TransformBroadcaster(self), g("odom_frame"), g("base_frame"),
                                  g("publish_tf"))
        self.bat_pub = self.create_publisher(BatteryState, "battery", 5)

        self.ser = self.open_port(g("port"), g("baud"))
        self.lock = threading.Lock()
        self.x = self.y = self.yaw = 0.0
        self.prev = None  # previous (odl, odr) in m
        self.frames = 0
        self.sent_stop = False
        self.running = True
        self.write({"T": 131, "cmd": 1})  # continuous feedback on (default, but be sure)
        threading.Thread(target=self.rx_loop, daemon=True).start()
        self.create_timer(1.0 / g("cmd_rate"), self.send_cmd)
        self.create_timer(5.0, self.report)

    def open_port(self, pattern, baud):
        matches = sorted(glob.glob(pattern)) or [pattern]
        port = matches[0]
        s = serial.Serial()
        s.port, s.baudrate, s.timeout = port, baud, 0.1
        s.dtr = False  # do not pulse the ESP32 auto-reset lines when opening
        s.rts = False
        s.open()
        self.get_logger().info(f"opened {port} at {baud}")
        return s

    def write(self, obj):
        line = (json.dumps(obj, separators=(",", ":")) + "\n").encode()
        with self.lock:
            try:
                self.ser.write(line)
            except serial.SerialException as e:
                self.get_logger().error(f"serial write failed: {e}", throttle_duration_sec=5.0)

    def send_cmd(self):
        v, w = self.gate.current()
        if v == 0.0 and w == 0.0:
            if self.sent_stop:  # one stop is enough, do not flood the ESP32 with zeros
                return
            self.sent_stop = True
        else:
            self.sent_stop = False
        self.write({"T": 13, "X": round(v, 3), "Z": round(w, 3)})

    def rx_loop(self):
        buf = b""
        while self.running:
            try:
                buf += self.ser.read(512)
            except serial.SerialException as e:
                self.get_logger().error(f"serial read failed: {e}", throttle_duration_sec=5.0)
                time.sleep(0.5)
                continue
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line = line.strip()
                if not line.startswith(b"{"):
                    continue  # boot log, debug prints
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue
                if msg.get("T") == 1001:
                    self.on_feedback(msg)

    def on_feedback(self, msg):
        self.frames += 1
        l_m, r_m = msg.get("odl", 0) / 100.0, msg.get("odr", 0) / 100.0
        if self.prev is not None:
            dl, dr = l_m - self.prev[0], r_m - self.prev[1]
            ds = (dl + dr) / 2.0
            dth = (dr - dl) / self.track
            mid = self.yaw + dth / 2.0
            self.x += ds * math.cos(mid)
            self.y += ds * math.sin(mid)
            self.yaw = math.atan2(math.sin(self.yaw + dth), math.cos(self.yaw + dth))
        self.prev = (l_m, r_m)
        self.odom.publish(self.x, self.y, self.yaw)

        if "v" in msg:
            bat = BatteryState()
            bat.header.stamp = self.get_clock().now().to_msg()
            bat.voltage = msg["v"] / 100.0
            bat.present = True
            bat.power_supply_technology = BatteryState.POWER_SUPPLY_TECHNOLOGY_LION
            # 3S Li-ion: 9.0 V empty .. 12.6 V full
            bat.percentage = max(0.0, min(1.0, (bat.voltage - 9.0) / 3.6))
            self.bat_pub.publish(bat)

    def report(self):
        if self.frames == 0:
            self.get_logger().warn("no {\"T\":1001} feedback from the chassis in 5 s: wrong port, "
                                   "or the robot is switched off")
        self.frames = 0

    def stop(self):
        self.running = False
        for _ in range(3):
            self.write({"T": 13, "X": 0, "Z": 0})
            time.sleep(0.05)
        self.ser.close()


def main():
    rclpy.init()
    node = CobraBase()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
