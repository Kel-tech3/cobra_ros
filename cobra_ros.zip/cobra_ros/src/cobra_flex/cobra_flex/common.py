"""Helpers shared by the simulator bridge and the real robot driver."""
import math
import time

from geometry_msgs.msg import TransformStamped, Twist
from nav_msgs.msg import Odometry


def clamp(x, lim):
    return max(-lim, min(lim, x))


def yaw_quat(yaw):
    return 0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0)


class CmdVelGate:
    """Last /cmd_vel with a timeout: a stale command becomes a stop."""

    def __init__(self, timeout, max_linear, max_angular):
        self.timeout = timeout
        self.max_linear = max_linear
        self.max_angular = max_angular
        self.v = self.w = 0.0
        self.stamp = 0.0

    def update(self, msg: Twist):
        self.v = clamp(msg.linear.x, self.max_linear)
        self.w = clamp(msg.angular.z, self.max_angular)
        self.stamp = time.monotonic()

    def current(self):
        if time.monotonic() - self.stamp > self.timeout:
            return 0.0, 0.0
        return self.v, self.w


class OdomPublisher:
    """Publishes nav_msgs/Odometry and the odom -> base TF from (x, y, yaw)."""

    def __init__(self, node, tf_broadcaster, odom_frame, base_frame, publish_tf):
        self.node = node
        self.pub = node.create_publisher(Odometry, "odom", 10)
        self.tf = tf_broadcaster
        self.odom_frame = odom_frame
        self.base_frame = base_frame
        self.publish_tf = publish_tf
        self.last = None  # (t, x, y, yaw) for velocity

    def publish(self, x, y, yaw):
        now = self.node.get_clock().now()
        t = now.nanoseconds * 1e-9
        vx = vth = 0.0
        if self.last is not None:
            dt = t - self.last[0]
            if dt > 1e-3:
                dx, dy = x - self.last[1], y - self.last[2]
                vx = (dx * math.cos(yaw) + dy * math.sin(yaw)) / dt
                dyaw = math.atan2(math.sin(yaw - self.last[3]), math.cos(yaw - self.last[3]))
                vth = dyaw / dt
        self.last = (t, x, y, yaw)

        qx, qy, qz, qw = yaw_quat(yaw)
        msg = Odometry()
        msg.header.stamp = now.to_msg()
        msg.header.frame_id = self.odom_frame
        msg.child_frame_id = self.base_frame
        msg.pose.pose.position.x = x
        msg.pose.pose.position.y = y
        msg.pose.pose.orientation.x = qx
        msg.pose.pose.orientation.y = qy
        msg.pose.pose.orientation.z = qz
        msg.pose.pose.orientation.w = qw
        msg.twist.twist.linear.x = vx
        msg.twist.twist.angular.z = vth
        # wheel odometry of a skid-steer robot: position fair, heading poor
        msg.pose.covariance[0] = msg.pose.covariance[7] = 0.01
        msg.pose.covariance[35] = 0.1
        msg.twist.covariance[0] = 0.01
        msg.twist.covariance[35] = 0.1
        self.pub.publish(msg)

        if self.publish_tf:
            tf = TransformStamped()
            tf.header = msg.header
            tf.child_frame_id = self.base_frame
            tf.transform.translation.x = x
            tf.transform.translation.y = y
            tf.transform.rotation.x = qx
            tf.transform.rotation.y = qy
            tf.transform.rotation.z = qz
            tf.transform.rotation.w = qw
            self.tf.sendTransform(tf)
