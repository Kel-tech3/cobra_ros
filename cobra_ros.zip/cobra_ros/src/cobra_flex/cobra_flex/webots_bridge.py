"""ROS 2 <-> Webots controller bridge.

Subscribes: /cmd_vel (geometry_msgs/Twist)
Publishes:  /odom + TF odom->base_footprint, /imu, /scan,
            /camera/depth/image_raw + camera_info (16UC1, mm), /camera/color/image_raw (bgra8)

Works with webots/controllers/cobra_udp from this repository (everything over one TCP stream; the
LiDAR geometry and gyro axes come from its WBTL packets) and with older controllers without WBTL.
"""
import math
import os
import socket
import threading
import time

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from sensor_msgs.msg import CameraInfo, Image, Imu, LaserScan
from tf2_ros import TransformBroadcaster

from cobra_flex import protocol
from cobra_flex.common import CmdVelGate, OdomPublisher


class WebotsBridge(Node):
    def __init__(self):
        super().__init__("webots_bridge")
        p = self.declare_parameter
        # network; the env vars CMD_HOST / CMD_PORT / TEL_PORT / PROTO win over parameters
        p("proto", "tcp")
        p("tel_host", "0.0.0.0")
        p("tel_port", 5600)
        p("cmd_host", "127.0.0.1")
        p("cmd_port", 5555)
        # motion
        p("cmd_rate", 20.0)
        p("cmd_timeout", 0.5)
        p("max_linear", 0.5)
        p("max_angular", 2.0)
        # sensors
        p("lidar_fov", 1.5708)
        # the next four are overridden by WBTL packets from cobra_udp; the defaults suit older
        # controllers (90 deg LiDAR, Y-up model)
        p("lidar_reverse", False)     # true if obstacles on the left show up on the right in RViz
        p("lidar_range_min", 0.02)
        p("lidar_range_max", 8.0)
        p("gyro_frame", "proto_yup")  # "flu" = already x forward, y left, z up
        p("depth_hfov", 1.518)
        # frames
        p("odom_frame", "odom")
        p("base_frame", "base_footprint")
        p("laser_frame", "laser")
        p("imu_frame", "base_link")
        p("depth_frame", "camera_depth_optical_frame")
        p("color_frame", "camera_color_optical_frame")
        p("publish_tf", True)

        g = lambda name: self.get_parameter(name).value  # noqa: E731
        self.proto = os.getenv("PROTO", g("proto")).lower()
        self.tel_host = g("tel_host")
        self.tel_port = int(os.getenv("TEL_PORT", g("tel_port")))
        self.cmd_addr = (os.getenv("CMD_HOST", g("cmd_host")), int(os.getenv("CMD_PORT", g("cmd_port"))))
        self.lidar_fov = g("lidar_fov")
        self.lidar_reverse = g("lidar_reverse")
        self.range_min = g("lidar_range_min")
        self.range_max = g("lidar_range_max")
        self.gyro_frame = g("gyro_frame")
        self.depth_hfov = g("depth_hfov")
        self.laser_frame = g("laser_frame")
        self.imu_frame = g("imu_frame")
        self.depth_frame = g("depth_frame")
        self.color_frame = g("color_frame")

        self.gate = CmdVelGate(g("cmd_timeout"), g("max_linear"), g("max_angular"))
        self.create_subscription(Twist, "cmd_vel", self.gate.update, 10)
        self.cmd_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.create_timer(1.0 / g("cmd_rate"), self.send_cmd)

        self.odom = OdomPublisher(self, TransformBroadcaster(self), g("odom_frame"), g("base_frame"),
                                  g("publish_tf"))
        self.imu_pub = self.create_publisher(Imu, "imu", 10)
        self.scan_pub = self.create_publisher(LaserScan, "scan", 10)
        self.depth_pub = self.create_publisher(Image, "camera/depth/image_raw", 5)
        self.info_pub = self.create_publisher(CameraInfo, "camera/depth/camera_info", 5)
        self.rgb_pub = self.create_publisher(Image, "camera/color/image_raw", 5)

        self.last_th = None
        self.gyro_checked = False
        self.counts = {"WBTG": 0, "WBTD": 0, "WBTR": 0}
        self.lidar_info = None
        self.running = True
        threading.Thread(target=self.rx_loop, daemon=True).start()
        self.create_timer(5.0, self.report)
        self.get_logger().info(
            f"telemetry {self.proto}://{self.tel_host}:{self.tel_port}, commands udp://{self.cmd_addr[0]}:{self.cmd_addr[1]}")

    # ---------- commands ----------
    def send_cmd(self, v=None, w=None):
        if v is None:
            v, w = self.gate.current()
        try:
            self.cmd_sock.sendto(protocol.pack_cmd(v, w), self.cmd_addr)
        except OSError as e:
            self.get_logger().warn(f"command send failed: {e}", throttle_duration_sec=5.0)

    def stop(self):
        self.running = False
        for _ in range(3):
            self.send_cmd(0.0, 0.0)
            time.sleep(0.05)

    # ---------- telemetry ----------
    def rx_loop(self):
        if self.proto == "udp":
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 * 1024 * 1024)
            s.bind((self.tel_host, self.tel_port))
            s.settimeout(0.5)
            joiner = protocol.Reassembler()
            while self.running:
                try:
                    dgram, _ = s.recvfrom(65535)
                except socket.timeout:
                    continue
                payload = joiner.feed(dgram)
                if payload:
                    self.on_payload(payload)
            return

        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((self.tel_host, self.tel_port))
        srv.listen(1)
        srv.settimeout(0.5)
        while self.running:
            try:
                conn, addr = srv.accept()
            except socket.timeout:
                continue
            self.get_logger().info(f"simulator connected from {addr[0]}")
            conn.settimeout(0.5)
            framer = protocol.TcpFramer()
            while self.running:
                try:
                    data = conn.recv(65536)
                except socket.timeout:
                    continue
                except OSError:
                    break
                if not data:
                    break
                for payload in framer.feed(data):
                    self.on_payload(payload)
            conn.close()
            self.get_logger().warn("simulator disconnected, waiting for it again")

    def on_payload(self, payload):
        try:
            if payload.startswith((protocol.WBTG, protocol.WBT2)):
                self.on_telemetry(protocol.parse_telemetry(payload))
            elif payload.startswith(protocol.WBTL):
                self.on_lidar_info(protocol.parse_lidar_info(payload))
            elif payload.startswith(protocol.WBTD):
                self.on_depth(protocol.parse_depth(payload))
            elif payload.startswith(protocol.WBTR):
                self.on_rgb(protocol.parse_rgb(payload))
        except Exception as e:  # a bad packet must not kill the bridge
            self.get_logger().error(f"bad packet {payload[:4]!r}: {e}", throttle_duration_sec=5.0)

    def report(self):
        self.get_logger().info("received in 5 s: " + ", ".join(f"{k} {v}" for k, v in self.counts.items()))
        self.counts = dict.fromkeys(self.counts, 0)

    def on_lidar_info(self, info):
        if info is None or info == self.lidar_info:
            return
        self.lidar_info = info
        self.lidar_fov = info["fov"]
        self.range_min, self.range_max = info["range_min"], info["range_max"]
        self.gyro_frame = "flu" if info["gyro_robot_frame"] else "proto_yup"
        self.get_logger().info(
            f"LiDAR {math.degrees(self.lidar_fov):.0f} deg, {self.range_min:.2f}-{self.range_max:.1f} m, "
            f"gyro frame {self.gyro_frame} (from the simulator)")

    def base_rates(self, gyro):
        """Gyro vector in the robot's own frame (x forward, y left, z up)."""
        wx, wy, wz = gyro
        if self.gyro_frame == "proto_yup":  # proto: x back, y up, z left
            return -wx, wz, wy
        return wx, wy, wz

    def on_telemetry(self, t):
        if t is None:
            return
        self.counts["WBTG"] += 1
        self.odom.publish(t["x"], t["y"], t["th"])
        now = self.get_clock().now().to_msg()

        if t["gyro"] is not None:  # WBT2 (early maze world) has no gyro
            rx, ry, rz = self.base_rates(t["gyro"])
            imu = Imu()
            imu.header.stamp = now
            imu.header.frame_id = self.imu_frame
            imu.orientation_covariance[0] = -1.0  # no orientation, only rates
            imu.angular_velocity.x, imu.angular_velocity.y, imu.angular_velocity.z = rx, ry, rz
            imu.angular_velocity_covariance = [0.01, 0.0, 0.0, 0.0, 0.01, 0.0, 0.0, 0.0, 0.01]
            imu.linear_acceleration_covariance[0] = -1.0
            self.imu_pub.publish(imu)
            self.check_gyro(t["th"], rz)

        ranges = list(t["ranges"])
        if ranges:
            if self.lidar_reverse:
                ranges.reverse()
            scan = LaserScan()
            scan.header.stamp = now
            scan.header.frame_id = self.laser_frame
            full = self.lidar_fov > 2 * math.pi - 1e-3  # 360 deg: the last ray must not repeat the first
            scan.angle_increment = self.lidar_fov / max(1, len(ranges) if full else len(ranges) - 1)
            scan.angle_min = -self.lidar_fov / 2.0
            scan.angle_max = scan.angle_min + scan.angle_increment * (len(ranges) - 1)
            scan.scan_time = 0.1
            scan.range_min = self.range_min
            scan.range_max = self.range_max
            # the controller reports "no return" as range_max; REP 117 wants +inf
            scan.ranges = [r if r < self.range_max - 1e-3 else math.inf for r in ranges]
            self.scan_pub.publish(scan)

    def check_gyro(self, th, rz):
        """Warn once if the gyro axis mapping disagrees with odometry while turning."""
        t = time.monotonic()
        if self.gyro_checked or self.last_th is None:
            self.last_th = (t, th)
            return
        dt = t - self.last_th[0]
        if dt < 0.05:
            return
        rate = math.atan2(math.sin(th - self.last_th[1]), math.cos(th - self.last_th[1])) / dt
        self.last_th = (t, th)
        if abs(rate) > 0.3:
            self.gyro_checked = True
            if rz * rate < 0 or abs(rz) < 0.3 * abs(rate):
                self.get_logger().warn(
                    f"gyro yaw rate {rz:.2f} does not match odometry {rate:.2f} rad/s: "
                    "try gyro_frame:=flu")

    def camera_info(self, w, h, frame, stamp):
        f = (w / 2.0) / math.tan(self.depth_hfov / 2.0)
        info = CameraInfo()
        info.header.stamp = stamp
        info.header.frame_id = frame
        info.width, info.height = w, h
        info.distortion_model = "plumb_bob"
        info.d = [0.0] * 5
        cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
        info.k = [f, 0.0, cx, 0.0, f, cy, 0.0, 0.0, 1.0]
        info.r = [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0]
        info.p = [f, 0.0, cx, 0.0, 0.0, f, cy, 0.0, 0.0, 0.0, 1.0, 0.0]
        return info

    def on_depth(self, d):
        if d is None:
            return
        self.counts["WBTD"] += 1
        w, h, _mn, _mx, raw = d
        now = self.get_clock().now().to_msg()
        img = Image()
        img.header.stamp = now
        img.header.frame_id = self.depth_frame
        img.width, img.height = w, h
        img.encoding = "16UC1"
        img.is_bigendian = 0
        img.step = w * 2
        img.data = raw
        self.depth_pub.publish(img)
        self.info_pub.publish(self.camera_info(w, h, self.depth_frame, now))

    def on_rgb(self, r):
        if r is None:
            return
        self.counts["WBTR"] += 1
        w, h, raw = r
        img = Image()
        img.header.stamp = self.get_clock().now().to_msg()
        img.header.frame_id = self.color_frame
        img.width, img.height = w, h
        img.encoding = "bgra8"
        img.step = w * 4
        img.data = raw
        self.rgb_pub.publish(img)


def main():
    rclpy.init()
    node = WebotsBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
