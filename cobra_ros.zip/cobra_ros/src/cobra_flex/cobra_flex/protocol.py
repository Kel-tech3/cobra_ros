"""Wire format between the Webots controller (cobra_udp or an older one) and the bridge.

Commands to the robot:  UDP, 8 bytes, "<2f" = (linear m/s, angular rad/s).
Telemetry from the robot, one payload per message:
  WBTG  "WBTG" + "<9f" (x, y, th, vx, vy, vth, wx, wy, wz) + "<I" N + N x "<f" lidar ranges
  WBT2  same without the gyro: "<6f" + "<I" N + ranges (older controllers)
  WBTL  "WBTL" + "<fffI" (lidar fov rad, min range, max range, flags); flags bit 0 = gyro in robot frame.
        Sent by cobra_udp about once a second; without it the bridge uses its parameters.
  WBTD  "WBTD" + "<HHiff" (w, h, downsample, min_range, max_range) + w*h x "<H" depth, mm, 0 = no return
  WBTR  "WBTR" + "<HHi" (w, h, downsample) + w*h*4 bytes BGRA
Over TCP every payload is prefixed with "<I" length.
Over UDP a payload larger than one datagram is split into CHNK parts:
  "CHNK" + "<IIHH" (msg_id, total_len, idx, count) + part
"""
import struct
import time

WBTG = b"WBTG"
WBT2 = b"WBT2"
WBTL = b"WBTL"
WBTD = b"WBTD"
WBTR = b"WBTR"
CHNK = b"CHNK"

CMD = struct.Struct("<2f")
TEL = struct.Struct("<9fI")
TEL2 = struct.Struct("<6fI")
LIDAR = struct.Struct("<fffI")
DEPTH = struct.Struct("<HHiff")
RGB = struct.Struct("<HHi")
CHUNK = struct.Struct("<IIHH")
LEN = struct.Struct("<I")


def pack_cmd(v, w):
    return CMD.pack(v, w)


def parse_telemetry(p):
    """WBTG or WBT2 payload -> dict, or None. WBT2 has no gyro (reported as None)."""
    if p.startswith(WBTG) and len(p) >= 4 + TEL.size:
        x, y, th, vx, vy, vth, wx, wy, wz, n = TEL.unpack_from(p, 4)
        gyro, off = (wx, wy, wz), 4 + TEL.size
    elif p.startswith(WBT2) and len(p) >= 4 + TEL2.size:
        x, y, th, vx, vy, vth, n = TEL2.unpack_from(p, 4)
        gyro, off = None, 4 + TEL2.size
    else:
        return None
    n = min(n, (len(p) - off) // 4)
    ranges = struct.unpack_from(f"<{n}f", p, off) if n else ()
    return dict(x=x, y=y, th=th, vx=vx, vy=vy, vth=vth, gyro=gyro, ranges=ranges)


def parse_lidar_info(p):
    """WBTL payload -> dict(fov, range_min, range_max, gyro_robot_frame), or None."""
    if not p.startswith(WBTL) or len(p) < 4 + LIDAR.size:
        return None
    fov, rmin, rmax, flags = LIDAR.unpack_from(p, 4)
    return dict(fov=fov, range_min=rmin, range_max=rmax, gyro_robot_frame=bool(flags & 1))


def parse_depth(p):
    """WBTD payload -> (w, h, min_range, max_range, raw uint16 LE bytes), or None."""
    if not p.startswith(WBTD) or len(p) < 4 + DEPTH.size:
        return None
    w, h, _ds, mn, mx = DEPTH.unpack_from(p, 4)
    off = 4 + DEPTH.size
    raw = p[off:off + w * h * 2]
    if len(raw) != w * h * 2:
        return None
    return w, h, mn, mx, raw


def parse_rgb(p):
    """WBTR payload -> (w, h, raw BGRA bytes), or None."""
    if not p.startswith(WBTR) or len(p) < 4 + RGB.size:
        return None
    w, h, _ds = RGB.unpack_from(p, 4)
    off = 4 + RGB.size
    raw = p[off:off + w * h * 4]
    if len(raw) != w * h * 4:
        return None
    return w, h, raw


class TcpFramer:
    """Splits a TCP byte stream into length-prefixed payloads."""

    MAX = 16 * 1024 * 1024

    def __init__(self):
        self.buf = bytearray()

    def feed(self, data):
        self.buf += data
        out = []
        while len(self.buf) >= LEN.size:
            (n,) = LEN.unpack_from(self.buf, 0)
            if n > self.MAX:  # lost sync: drop everything
                self.buf.clear()
                break
            if len(self.buf) < LEN.size + n:
                break
            out.append(bytes(self.buf[LEN.size:LEN.size + n]))
            del self.buf[:LEN.size + n]
        return out


class Reassembler:
    """Joins CHNK datagrams back into payloads; plain datagrams pass through."""

    def __init__(self, timeout=1.0):
        self.timeout = timeout
        self.pending = {}

    def feed(self, dgram):
        if not dgram.startswith(CHNK):
            return dgram
        msg_id, total, idx, count = CHUNK.unpack_from(dgram, 4)
        now = time.monotonic()
        for k in [k for k, v in self.pending.items() if now - v[2] > self.timeout]:
            del self.pending[k]
        parts, _, _ = self.pending.setdefault(msg_id, ({}, count, now))
        parts[idx] = dgram[4 + CHUNK.size:]
        if len(parts) < count:
            return None
        del self.pending[msg_id]
        payload = b"".join(parts[i] for i in range(count))
        return payload if len(payload) == total else None
