"""Tiny stand-in for the Webots `controller` module, only for testing cobra_udp without Webots.

Kinematics: skid-steer from motor velocities. Sensors are synthetic and chosen so that mistakes
are visible: the 360 degree lidar sees a wall at 1.0 m on the robot's LEFT and 3.0 m elsewhere,
in Webots order (ray 0 at +180 degrees, then clockwise); the gyro reports yaw about +z.
"""
import math
import time

R, TRACK = 0.037, 0.164


class _Motor:
    def __init__(self):
        self.vel = 0.0

    def setPosition(self, p):
        pass

    def setVelocity(self, v):
        self.vel = max(-20.0, min(20.0, v))

    def getMaxVelocity(self):
        return 20.0


class _Encoder:
    def __init__(self, motor):
        self.motor, self.angle = motor, 0.0

    def enable(self, ts):
        pass

    def getValue(self):
        return self.angle


class _Lidar:
    N = 360

    def enable(self, ts):
        pass

    def getFov(self):
        return 2 * math.pi

    def getMinRange(self):
        return 0.12

    def getMaxRange(self):
        return 12.0

    def getRangeImage(self):  # Webots order: ray k at angle pi - k * 2pi / N (left side first)
        angles = [math.pi - k * 2 * math.pi / self.N for k in range(self.N)]
        return [1.0 if 0.1 < a < math.pi - 0.1 else 3.0 for a in angles]


class _Gyro:
    def __init__(self, robot):
        self.robot = robot

    def enable(self, ts):
        pass

    def getValues(self):
        return [0.0, 0.0, self.robot.yaw_rate]  # robot frame: yaw is about +z


class _Depth:
    W, H = 64, 48

    def enable(self, ts):
        pass

    def getWidth(self):
        return self.W

    def getHeight(self):
        return self.H

    def getMinRange(self):
        return 0.1

    def getMaxRange(self):
        return 6.0

    def getRangeImage(self):  # floor gets closer towards the bottom rows, last two rows = no return
        return [(0.5 + 3.0 * (1 - r / self.H)) if r < self.H - 2 else float("inf")
                for r in range(self.H) for _ in range(self.W)]


class Robot:
    def __init__(self):
        self.m = {n: _Motor() for n in ("left_front_motor", "left_rear_motor",
                                         "right_front_motor", "right_rear_motor")}
        self.e = {n.replace("motor", "encoder"): _Encoder(mo) for n, mo in self.m.items()}
        self.yaw_rate = 0.0
        self.devices = dict(self.m, **self.e, lidar=_Lidar(), gyro=_Gyro(self), depth=_Depth())

    def getBasicTimeStep(self):
        return 16

    def getDevice(self, name):
        return self.devices.get(name)

    def step(self, ts):
        dt = ts / 1000.0
        time.sleep(dt)
        for enc in self.e.values():
            enc.angle += enc.motor.vel * dt
        wl = (self.m["left_front_motor"].vel + self.m["left_rear_motor"].vel) / 2.0
        wr = (self.m["right_front_motor"].vel + self.m["right_rear_motor"].vel) / 2.0
        self.yaw_rate = (wr - wl) * R / TRACK
        return 0 if math.isfinite(self.yaw_rate) else -1
