#!/usr/bin/env python3
"""Pretends to be the Cobra Flex ESP32 on a pseudo-terminal, for testing cobra_base without a robot.

python3 tools/fake_esp32.py /tmp/cobra_esp32      # then: cobra_base --ros-args -p port:=/tmp/cobra_esp32

Understands {"T":13,"X":v,"Z":w} (with the 3 s heartbeat) and {"T":131}; sends
{"T":1001,...,"odl":cm,"odr":cm,"v":volts*100} at 20 Hz, like the factory firmware.
"""
import json
import os
import pty
import select
import sys
import time

TRACK = 0.159  # firmware TRACK_WIDTH used by {"T":13}
link = sys.argv[1] if len(sys.argv) > 1 else "/tmp/cobra_esp32"

master, slave = pty.openpty()
if os.path.lexists(link):
    os.remove(link)
os.symlink(os.ttyname(slave), link)
print(f"fake ESP32 on {link} -> {os.ttyname(slave)}", flush=True)

odl = odr = 0.0
v = w = 0.0
last_cmd = 0.0
last_fb = time.monotonic()
buf = b""
while True:
    r, _, _ = select.select([master], [], [], 0.01)
    if r:
        buf += os.read(master, 1024)
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            try:
                msg = json.loads(line)
            except ValueError:
                continue
            print("rx", msg, flush=True)
            if msg.get("T") == 13:
                v, w = float(msg["X"]), float(msg["Z"])
                last_cmd = time.monotonic()
    now = time.monotonic()
    if now - last_cmd > 3.0:  # firmware heartbeat
        v = w = 0.0
    dt = now - last_fb
    if dt >= 0.05:
        last_fb = now
        odl += (v - w * TRACK / 2) * dt
        odr += (v + w * TRACK / 2) * dt
        fb = {"T": 1001, "M1": 0, "M2": 0, "M3": 0, "M4": 0,
              "odl": int(odl * 100), "odr": int(odr * 100), "v": 1180}
        os.write(master, (json.dumps(fb) + "\r\n").encode())
