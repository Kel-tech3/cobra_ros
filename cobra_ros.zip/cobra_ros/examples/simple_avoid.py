#!/usr/bin/env python3
"""Smallest useful node: drive forward, turn away from the closer side. Same code for Webots and the
real robot, because both give /scan and take /cmd_vel.

python3 simple_avoid.py
"""
import math

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from sensor_msgs.msg import LaserScan

SAFE = 0.5    # m: closer than this in front -> turn in place
SPEED = 0.15  # m/s


class SimpleAvoid(Node):
    def __init__(self):
        super().__init__("simple_avoid")
        self.pub = self.create_publisher(Twist, "cmd_vel", 10)
        self.create_subscription(LaserScan, "scan", self.on_scan, 10)

    def sector(self, scan, a_from, a_to):
        """Closest valid range between two angles (rad, 0 = forward, positive = left)."""
        best = math.inf
        for i, r in enumerate(scan.ranges):
            a = scan.angle_min + i * scan.angle_increment
            if a_from <= a <= a_to and scan.range_min < r < scan.range_max:
                best = min(best, r)
        return best

    def on_scan(self, scan):
        front = self.sector(scan, -0.2, 0.2)
        left = self.sector(scan, 0.2, 0.8)
        right = self.sector(scan, -0.8, -0.2)
        cmd = Twist()
        if front < SAFE:
            cmd.angular.z = 0.8 if left > right else -0.8   # turn towards the freer side
        else:
            cmd.linear.x = SPEED
            cmd.angular.z = 0.5 * (min(left, 2.0) - min(right, 2.0))  # keep away from the closer wall
        self.pub.publish(cmd)


def main():
    rclpy.init()
    node = SimpleAvoid()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.pub.publish(Twist())
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
