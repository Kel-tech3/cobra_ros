"""EKF (wheel odometry + gyro) + slam_toolbox + Nav2.

Start the robot side first, without its own odom TF (the EKF publishes it):
  ros2 launch cobra_flex sim.launch.py publish_tf:=false        # Webots
  ros2 launch cobra_flex robot.launch.py publish_tf:=false      # real robot (it has no gyro: see README)
then:
  ros2 launch /ws/examples/slam_nav2_ekf/stack.launch.py
and send a goal from RViz ("2D Goal Pose") or:
  ros2 action send_goal /navigate_to_pose nav2_msgs/action/NavigateToPose \
    "{pose: {header: {frame_id: map}, pose: {position: {x: 1.0, y: 0.0}, orientation: {w: 1.0}}}}"
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

HERE = os.path.dirname(os.path.abspath(__file__))


def generate_launch_description():
    nav2 = os.path.join(get_package_share_directory("nav2_bringup"), "launch", "navigation_launch.py")
    return LaunchDescription([
        Node(package="robot_localization", executable="ekf_node", name="ekf_filter_node", output="screen",
             parameters=[os.path.join(HERE, "ekf.yaml")]),
        Node(package="slam_toolbox", executable="async_slam_toolbox_node", name="slam_toolbox",
             output="screen", parameters=[os.path.join(HERE, "slam_toolbox.yaml")]),
        IncludeLaunchDescription(PythonLaunchDescriptionSource(nav2), launch_arguments={
            "params_file": os.path.join(HERE, "nav2_params.yaml"),
            "use_sim_time": "false",
        }.items()),
    ])
