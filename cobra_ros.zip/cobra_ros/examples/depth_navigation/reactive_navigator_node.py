#!/usr/bin/env python3
"""
Reactive Navigator Node - Skeleton-based path planning and navigation.

Subscribes to floor camera depth images, computes skeleton-based paths,
and publishes velocity commands to follow the centerline toward furthest point.
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
from visualization_msgs.msg import Marker
from cv_bridge import CvBridge
import cv2
import numpy as np

# Import proven skeleton-based path planning algorithms
import skeleton_path_planner


class ReactiveNavigatorNode(Node):
    """Reactive navigator using skeleton-based path planning."""

    def __init__(self):
        super().__init__("reactive_navigator")

        # Parameters
        self.declare_parameter("enabled", True)
        self.declare_parameter("linear_speed", 0.1)  # m/s
        self.declare_parameter("angular_speed", 0.5)  # rad/s
        self.declare_parameter("lookahead_distance", 100.0)  # pixels
        self.declare_parameter(
            "skeleton_bonus", 50000.0
        )  # Skeleton preference (scaled by 1000x for integer math, 50.0 effective value)
        self.declare_parameter("publish_viz", True)
        self.declare_parameter("debug_save_images", False)  # Save debug images to disk
        self.declare_parameter(
            "downsample_factor", 1
        )  # Image downsampling (1=no downsample, 2=half size)

        # State
        self.bridge = CvBridge()
        self.last_path = None
        self.planning_time = 0.0
        self.last_info_log_time = 0.0  # For throttling info logs

        # QoS profile matching bridge node (BEST_EFFORT, depth=1 for latest only)
        sensor_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,  # Only keep latest frame, discard old ones
        )

        # Subscribers
        self.depth_sub = self.create_subscription(
            Image, "/floor_camera/depth_thresholded", self.depth_callback, sensor_qos
        )

        # Publishers
        self.cmd_vel_pub = self.create_publisher(Twist, "/cmd_vel", 10)
        self.path_pub = self.create_publisher(Path, "/planned_path", 10)
        self.marker_pub = self.create_publisher(Marker, "/path_markers", 10)

        self.get_logger().info("Reactive Navigator Node initialized")
        self.get_logger().info(f'  Enabled: {self.get_parameter("enabled").value}')
        self.get_logger().info(
            f'  Linear speed: {self.get_parameter("linear_speed").value} m/s'
        )
        self.get_logger().info(
            f'  Angular speed: {self.get_parameter("angular_speed").value} rad/s'
        )
        self.get_logger().info(
            f'  Downsample factor: {self.get_parameter("downsample_factor").value}x'
        )
        self.get_logger().info(
            f'  Debug images: {self.get_parameter("debug_save_images").value}'
        )

    def compute_skeleton(self, binary_img):
        """Compute morphological skeleton using proven algorithm."""
        import time

        t_start = time.perf_counter()

        # Use proven experimental code
        skeleton = skeleton_path_planner.compute_skeleton(binary_img)

        t_end = time.perf_counter()
        skeleton_time = (t_end - t_start) * 1000.0
        skeleton_pixels = int(np.sum(skeleton))

        self.get_logger().debug(
            f"[SKELETON] Computed in {skeleton_time:.1f}ms, {skeleton_pixels} pixels"
        )

        return skeleton

    def bfs_distance(self, floor_mask, start_point):
        """Compute geodesic distance using proven BFS algorithm."""
        import time

        floor_pixels = np.sum(floor_mask)
        self.get_logger().debug(
            f"[BFS] Starting from {start_point}, floor has {floor_pixels} pixels"
        )
        t_start = time.perf_counter()

        # Use proven experimental code
        distance_map = skeleton_path_planner.bfs_distance(
            floor_mask, start_point, self.get_logger()
        )

        t_end = time.perf_counter()
        bfs_time = (t_end - t_start) * 1000.0
        max_dist = np.max(distance_map) / 1000.0  # Convert back to float

        self.get_logger().debug(
            f"[BFS] Completed in {bfs_time:.1f}ms, max_dist={max_dist:.1f}px"
        )

        return distance_map

    def find_furthest_skeleton_point(self, skeleton, distance_map):
        """Find skeleton point with maximum geodesic distance using proven algorithm."""
        return skeleton_path_planner.find_furthest_point_on_skeleton(
            skeleton, distance_map
        )

    def trace_path(self, distance_map, start_point, end_point, skeleton=None):
        """Trace path with skeleton preference using proven algorithm."""
        skeleton_bonus = self.get_parameter("skeleton_bonus").value
        return skeleton_path_planner.trace_path(
            distance_map, start_point, end_point, skeleton, skeleton_bonus
        )

    def compute_path(self, depth_image):
        """
        Compute skeleton-based path from depth image.

        Returns:
            path: List of (x, y) waypoints in pixel coordinates
            skeleton: Boolean skeleton array
            end_point: Goal point
        """
        import time

        t_start = time.perf_counter()

        # Optional downsampling for faster processing
        downsample_factor = self.get_parameter("downsample_factor").value
        h_orig, w_orig = depth_image.shape

        if downsample_factor > 1:
            depth_image_small = cv2.resize(
                depth_image,
                (w_orig // downsample_factor, h_orig // downsample_factor),
                interpolation=cv2.INTER_NEAREST,
            )
        else:
            depth_image_small = depth_image

        h, w = depth_image_small.shape
        start_point = (w // 2, h - 5)  # Bottom center

        # Step 1: Skeleton on original downsampled image
        skeleton = self.compute_skeleton(depth_image_small)
        skeleton_pixels = int(skeleton.sum())

        if skeleton_pixels == 0:
            self.get_logger().warn("No skeleton found")
            return None, None, None

        # Step 2: Distance map on ERODED floor (adds safety margin from walls)
        floor_mask = (depth_image_small > 127).astype(np.uint8)
        erode_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        floor_mask_eroded = cv2.erode(floor_mask, erode_kernel, iterations=5)
        distance_map = self.bfs_distance(floor_mask_eroded, start_point)

        # Step 3: Find furthest point
        end_point, end_dist = self.find_furthest_skeleton_point(skeleton, distance_map)

        if end_point is None:
            self.get_logger().warn("No valid goal found")
            return None, None, None

        # Step 4: Trace path
        path = self.trace_path(distance_map, start_point, end_point, skeleton=skeleton)

        # Optional debug image saving
        if self.get_parameter("debug_save_images").value:
            import os

            debug_dir = "/app/maps/debug-planning"
            os.makedirs(debug_dir, exist_ok=True)

            timestamp = int(time.time() * 1000)

            # Save source depth image
            source_filename = f"{debug_dir}/{timestamp}_source.png"
            cv2.imwrite(source_filename, depth_image_small)

            # Save skeleton image
            skeleton_img = skeleton.astype(np.uint8) * 255
            skeleton_filename = f"{debug_dir}/{timestamp}_skeleton.png"
            cv2.imwrite(skeleton_filename, skeleton_img)

            # Create visualization with path
            vis = cv2.cvtColor(depth_image_small, cv2.COLOR_GRAY2BGR)

            # Draw skeleton in blue
            vis[skeleton] = [255, 100, 0]

            # Draw path in green
            if len(path) > 1:
                for i in range(len(path) - 1):
                    pt1 = path[i]
                    pt2 = path[i + 1]
                    cv2.line(vis, pt1, pt2, (0, 255, 0), 1)

            # Draw start point (cyan)
            cv2.circle(vis, start_point, 3, (255, 255, 0), -1)

            # Draw end point (magenta)
            cv2.circle(vis, end_point, 3, (255, 0, 255), -1)

            # Save visualization
            vis_filename = f"{debug_dir}/{timestamp}_viz.png"
            cv2.imwrite(vis_filename, vis)

            self.get_logger().debug(
                f"Debug saved: source_{timestamp}.png, skeleton_{timestamp}.png, viz_{timestamp}.png"
            )

        # Scale path back to original resolution if downsampled
        if downsample_factor > 1:
            path_scaled = [
                (int(x * downsample_factor), int(y * downsample_factor))
                for x, y in path
            ]
            end_point_scaled = (
                int(end_point[0] * downsample_factor),
                int(end_point[1] * downsample_factor),
            )
        else:
            path_scaled = path
            end_point_scaled = end_point

        t_end = time.perf_counter()
        self.planning_time = (t_end - t_start) * 1000.0

        self.get_logger().debug(
            f"Path planning: {self.planning_time:.1f}ms, "
            f"{len(path_scaled)} points, goal dist: {end_dist/1000.0:.1f}px"
        )

        return path_scaled, skeleton, end_point_scaled

    def path_to_cmd_vel(self, path, image_height):
        """
        Convert path waypoints to velocity command.

        Args:
            path: List of (x, y) waypoints
            image_height: Height of image (for coordinate system)

        Returns:
            Twist message
        """
        cmd = Twist()

        if path is None or len(path) < 2:
            # No valid path - stop
            self.get_logger().debug("[CONTROL] No valid path, sending STOP command")
            return cmd

        # Robot is at bottom-center of image
        robot_x = path[0][0]
        robot_y = path[0][1]

        # Find lookahead point
        lookahead_dist = self.get_parameter("lookahead_distance").value
        lookahead_point = None
        lookahead_index = None

        cumulative_dist = 0.0
        for i in range(1, len(path)):
            p1 = path[i - 1]
            p2 = path[i]
            segment_dist = np.sqrt((p2[0] - p1[0]) ** 2 + (p2[1] - p1[1]) ** 2)
            cumulative_dist += segment_dist

            if cumulative_dist >= lookahead_dist:
                lookahead_point = p2
                lookahead_index = i
                break

        if lookahead_point is None:
            # Use end of path
            lookahead_point = path[-1]
            lookahead_index = len(path) - 1

        # Compute heading error
        # Image coordinates: x=right, y=down
        # Robot coordinates: x=forward (up in image), y=left
        dx = lookahead_point[0] - robot_x
        dy = robot_y - lookahead_point[1]  # Invert y (up is forward)

        # Angle to target (0 = straight ahead, + = left, - = right)
        # Note: Negate dx because image x increases to right, but ROS angular.z + is left
        target_angle = np.arctan2(-dx, dy) if dy > 0 else 0.0
        target_angle_deg = np.degrees(target_angle)

        # Control law
        linear_speed = self.get_parameter("linear_speed").value
        angular_speed = self.get_parameter("angular_speed").value

        # Proportional angular control
        cmd.linear.x = linear_speed
        cmd.angular.z = angular_speed * np.clip(target_angle, -1.0, 1.0)

        self.get_logger().debug(
            f"[CONTROL] Lookahead[{lookahead_index}/{len(path)}]: ({lookahead_point[0]}, {lookahead_point[1]}), "
            f"dx={dx:.1f}, dy={dy:.1f}, angle={target_angle_deg:.1f}°, "
            f"v={cmd.linear.x:.3f}, ω={cmd.angular.z:.3f}"
        )

        return cmd

    def publish_visualization(self, path, end_point):
        """Publish path and marker visualizations."""
        if not self.get_parameter("publish_viz").value:
            return

        if path is None:
            return

        # Publish Path message
        path_msg = Path()
        path_msg.header.stamp = self.get_clock().now().to_msg()
        path_msg.header.frame_id = "floor_camera"

        for px, py in path:
            pose = PoseStamped()
            pose.header = path_msg.header
            pose.pose.position.x = float(px)
            pose.pose.position.y = float(py)
            pose.pose.position.z = 0.0
            path_msg.poses.append(pose)

        self.path_pub.publish(path_msg)

        # Publish goal marker
        if end_point is not None:
            marker = Marker()
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.header.frame_id = "floor_camera"
            marker.ns = "goal"
            marker.id = 0
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose.position.x = float(end_point[0])
            marker.pose.position.y = float(end_point[1])
            marker.pose.position.z = 0.0
            marker.scale.x = 10.0
            marker.scale.y = 10.0
            marker.scale.z = 10.0
            marker.color.r = 1.0
            marker.color.g = 0.0
            marker.color.b = 1.0
            marker.color.a = 1.0

            self.marker_pub.publish(marker)

    def depth_callback(self, msg):
        """Process depth image and navigate."""
        import time

        if not self.get_parameter("enabled").value:
            self.get_logger().debug("Navigator disabled, skipping")
            return

        self.get_logger().debug(
            f"[DEPTH RX] Image received: {msg.width}x{msg.height}, encoding={msg.encoding}"
        )

        # Convert ROS Image to OpenCV
        try:
            depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding="mono8")
            floor_pixels = np.sum(depth_image > 127)
            total_pixels = depth_image.shape[0] * depth_image.shape[1]
            floor_pct = 100.0 * floor_pixels / total_pixels
            self.get_logger().debug(
                f"[IMAGE] Size: {depth_image.shape[1]}x{depth_image.shape[0]}, "
                f"Floor pixels: {floor_pixels}/{total_pixels} ({floor_pct:.1f}%)"
            )
        except Exception as e:
            self.get_logger().error(f"[ERROR] Failed to convert image: {e}")
            return

        # Compute path
        self.get_logger().debug("[PLANNING] Starting path computation...")
        path, skeleton, end_point = self.compute_path(depth_image)

        # Store for potential reuse
        self.last_path = path

        if path is None:
            self.get_logger().warn("[PLANNING] No valid path found - STOPPING")
            cmd = Twist()  # Stop command
            self.cmd_vel_pub.publish(cmd)
            return

        # Compute velocity command
        cmd = self.path_to_cmd_vel(path, depth_image.shape[0])

        # Publish
        self.cmd_vel_pub.publish(cmd)
        self.publish_visualization(path, end_point)

        # Throttled info logging (once per 4 seconds)
        current_time = time.time()
        if current_time - self.last_info_log_time >= 4.0:
            self.get_logger().info(
                f"[NAV] Planning: {self.planning_time:.1f}ms | "
                f"Path: {len(path)} pts | "
                f"Goal: ({end_point[0]}, {end_point[1]}) | "
                f"v={cmd.linear.x:.3f} m/s, ω={cmd.angular.z:.3f} rad/s"
            )
            self.last_info_log_time = current_time
        else:
            self.get_logger().debug(
                f"[RESULT] Planning: {self.planning_time:.1f}ms | "
                f"Path: {len(path)} waypoints | "
                f"Goal: ({end_point[0]}, {end_point[1]}) | "
                f"Cmd: v={cmd.linear.x:.3f} m/s, ω={cmd.angular.z:.3f} rad/s"
            )


def main(args=None):
    rclpy.init(args=args)
    node = ReactiveNavigatorNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # Stop robot
        node.cmd_vel_pub.publish(Twist())
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
