#!/usr/bin/env python3
"""Adapter for reactive_navigator_node.py: depth image (16UC1 mm or 32FC1 m) -> floor mask.

In:  /camera/depth/image_raw  (from cobra_flex webots_bridge, or a RealSense / OAK driver)
Out: /floor_camera/depth_thresholded  mono8 160x120, 255 = floor (0 < depth <= max_floor_depth), 0 = no floor

On a platform over empty space, "no floor" is the edge: the depth camera sees nothing there.
"""
import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import Image


class DepthFloorMask(Node):
    def __init__(self):
        super().__init__("depth_floor_mask")
        self.declare_parameter("max_floor_depth", 5.0)  # m, same as the original solution
        self.declare_parameter("width", 160)            # the navigator is tuned for 160x120
        self.declare_parameter("height", 120)
        qos = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT, history=HistoryPolicy.KEEP_LAST, depth=1)
        self.pub = self.create_publisher(Image, "/floor_camera/depth_thresholded", qos)
        self.create_subscription(Image, "/camera/depth/image_raw", self.on_depth, 5)

    def on_depth(self, msg):
        if msg.encoding in ("16UC1", "mono16"):
            depth = np.frombuffer(bytes(msg.data), dtype="<u2").reshape(msg.height, msg.width) / 1000.0
        elif msg.encoding == "32FC1":
            depth = np.frombuffer(bytes(msg.data), dtype="<f4").reshape(msg.height, msg.width)
        else:
            self.get_logger().error(f"unsupported encoding {msg.encoding}", throttle_duration_sec=5.0)
            return
        limit = self.get_parameter("max_floor_depth").value
        mask = np.logical_and(depth > 0, depth <= limit).astype(np.uint8) * 255
        w, h = self.get_parameter("width").value, self.get_parameter("height").value
        mask = cv2.resize(mask, (w, h), interpolation=cv2.INTER_NEAREST)
        out = Image()
        out.header = msg.header
        out.height, out.width = mask.shape
        out.encoding = "mono8"
        out.step = out.width
        out.data = mask.tobytes()
        self.pub.publish(out)


def main():
    rclpy.init()
    node = DepthFloorMask()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
