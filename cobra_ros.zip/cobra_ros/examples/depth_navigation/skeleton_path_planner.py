#!/usr/bin/env python3
"""
Skeleton-based path planner library.

Provides functions for:
- Skeletonization of binary floor maps
- Geodesic distance computation via BFS
- Path tracing with skeleton preference
"""

import cv2
import numpy as np
from collections import deque


def compute_skeleton(binary_img):
    """
    Compute morphological skeleton of white floor area using iterative thinning.
    Returns skeleton as binary image (True = skeleton pixels).
    """
    # binary_img should have white floor (255) and black obstacles (0)
    # Create binary mask
    _, floor_mask = cv2.threshold(binary_img, 127, 255, cv2.THRESH_BINARY)

    # Morphological skeleton using iterative erosion
    # See: https://docs.opencv.org/3.4/df/d2d/group__ximgproc.html

    size = np.size(floor_mask)
    skeleton = np.zeros(floor_mask.shape, dtype=np.uint8)

    # Get structuring element
    element = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))

    while True:
        # Erode and dilate
        eroded = cv2.erode(floor_mask, element)
        temp = cv2.dilate(eroded, element)
        temp = cv2.subtract(floor_mask, temp)
        skeleton = cv2.bitwise_or(skeleton, temp)
        floor_mask = eroded.copy()

        if cv2.countNonZero(floor_mask) == 0:
            break

    # Convert to boolean
    skeleton_bool = skeleton > 0

    # Fill small gaps (1-2 pixels) using morphological closing
    # This prevents path from "falling off" skeleton at gaps
    close_kernel = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    skeleton_uint8 = skeleton_bool.astype(np.uint8) * 255
    skeleton_closed = cv2.morphologyEx(skeleton_uint8, cv2.MORPH_CLOSE, close_kernel)

    skeleton_bool = skeleton_closed > 0

    return skeleton_bool


def bfs_distance(floor_mask, start_point, logger=None):
    """
    Compute exact geodesic distance using BFS.

    Args:
        floor_mask: Binary mask (1=floor, 0=obstacle)
        start_point: (x, y) starting position

    Returns:
        distance_map: Geodesic distance from start to each pixel (-1 for unreachable)
    """
    h, w = floor_mask.shape
    distance_map = np.full((h, w), -1, dtype=np.int32)

    start_x, start_y = start_point

    # Check if start point is valid
    if not (0 <= start_y < h and 0 <= start_x < w) or floor_mask[start_y, start_x] == 0:
        return distance_map

    # BFS queue: (x, y, distance)
    # Use integer distances (multiply by 1000 to avoid floating-point precision errors)
    queue = deque([(start_x, start_y, 0)])
    distance_map[start_y, start_x] = 0

    # 8-connectivity neighbors
    neighbors = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    # Distances for diagonal vs straight (multiplied by 1000 for integer math)
    neighbor_dists = [1414, 1000, 1414, 1000, 1000, 1414, 1000, 1414]

    # iter = 0
    # h, w = floor_mask.shape
    # if logger is not None:
    #     logger.info(f"Starting BFS for image {w}x{h}, start={start_point}")
    # else:
    #     print(f"Starting BFS for image {w}x{h}, start={start_point}")

    while queue:
        x, y, dist = queue.popleft()

        # Skip if we've already found a better path to this pixel
        if distance_map[y, x] < dist:
            continue

        # Check all neighbors
        for (dx, dy), step_dist in zip(neighbors, neighbor_dists):
            nx, ny = x + dx, y + dy

            # Check bounds
            if not (0 <= nx < w and 0 <= ny < h):
                continue

            # Check if floor and not visited
            if floor_mask[ny, nx] == 0:
                continue

            new_dist = dist + step_dist

            # If not visited or found shorter path
            if distance_map[ny, nx] < 0 or new_dist < distance_map[ny, nx]:
                # if iter < 4:
                #     if logger is not None:
                #         logger.info(
                #             f"Adding ({nx},{ny}) current={distance_map[ny, nx]} new={new_dist}"
                #         )
                #     else:
                #         print(
                #             f"Adding ({nx},{ny}) current={distance_map[ny, nx]} new={new_dist}"
                #         )
                distance_map[ny, nx] = new_dist
                queue.append((nx, ny, new_dist))

    return distance_map


def find_furthest_point_on_skeleton(skeleton, distance_map):
    """
    Find the skeleton point with maximum geodesic distance.

    Args:
        skeleton: Boolean array of skeleton pixels
        distance_map: Geodesic distance map

    Returns:
        (x, y): Coordinates of furthest skeleton point
        max_dist: Distance value at that point
    """
    # Mask distance map to only skeleton pixels
    skeleton_distances = np.where(skeleton, distance_map, -np.inf)

    # Find maximum
    max_dist = np.max(skeleton_distances)

    if max_dist == -np.inf or max_dist < 0:
        print("Warning: No valid skeleton point found!")
        return None, -1

    # Find coordinates of maximum
    max_pos = np.unravel_index(np.argmax(skeleton_distances), skeleton_distances.shape)
    max_y, max_x = max_pos

    return (max_x, max_y), max_dist


def trace_path(
    distance_map, start_point, end_point, skeleton=None, skeleton_bonus=5000.0
):
    """
    Trace path from end_point back to start_point using gradient descent on distance map.
    If skeleton is provided, skeleton pixels are strongly preferred (given a bonus).

    Args:
        distance_map: Geodesic distance map (integer, scaled by 1000)
        start_point: (x, y) start
        end_point: (x, y) goal
        skeleton: Optional boolean array - if provided, skeleton pixels are preferred
        skeleton_bonus: Bonus for skeleton pixels (scaled by 1000x for integer math)
                       Example: 5000 = 5.0 effective, 20000 = 20.0 effective (strong centering)

    Returns:
        path: List of (x, y) points from start to end
    """
    path = []
    current = end_point
    path.append(current)

    h, w = distance_map.shape

    # Track visited pixels to prevent loops
    visited = set()
    visited.add(current)

    # Trace back by following decreasing distance
    max_iterations = 10000
    iteration = 0

    while current != start_point and iteration < max_iterations:
        x, y = current
        current_dist = distance_map[y, x]

        # Check all 8 neighbors
        neighbors = [
            (-1, -1),
            (-1, 0),
            (-1, 1),
            (0, -1),
            (0, 1),
            (1, -1),
            (1, 0),
            (1, 1),
        ]

        best_neighbor = None
        best_score = np.inf

        for dx, dy in neighbors:
            nx, ny = x + dx, y + dy

            # Check bounds
            if not (0 <= nx < w and 0 <= ny < h):
                continue

            # Skip already visited pixels
            if (nx, ny) in visited:
                continue

            neighbor_dist = distance_map[ny, nx]

            # Skip unreachable pixels
            if neighbor_dist < 0:
                continue

            # Score = distance (lower is better)
            # But give skeleton pixels a strong bonus to keep path centered
            score = neighbor_dist
            if skeleton is not None and skeleton[ny, nx]:
                score -= skeleton_bonus  # Prefer skeleton pixels for centered path

            # Move to neighbor with best score (smallest effective distance)
            if score < best_score:
                best_score = score
                best_neighbor = (nx, ny)
                # if skeleton is not None and skeleton[ny, nx]:
                #     print(f"Skeleton at {nx},{ny}, score={score}")
                # else:
                #     print(f"No skeleton at {nx},{ny}, score={score}")

        if best_neighbor is None:
            # Reached start or got stuck
            break

        current = best_neighbor
        visited.add(current)
        path.append(current)
        iteration += 1

        # Early termination if we reached start
        if current == start_point:
            break

    # Reverse path so it goes from start to end
    path.reverse()

    return path
