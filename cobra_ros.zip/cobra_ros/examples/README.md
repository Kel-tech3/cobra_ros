# Code examples

All examples use the topics of `cobra_flex`, so the same code runs in Webots and on the real robot.

## simple_avoid.py

Drives forward and turns away from the nearer obstacle, using `/scan` and `/cmd_vel` only. Try it in `maze.wbt`.

```bash
python3 /ws/examples/simple_avoid.py
```

## slam_nav2_ekf: map and navigation to a goal

The stack consists of an EKF from `robot_localization` that combines wheel odometry and the gyro, `slam_toolbox` for the map, and Nav2 with the Smac Hybrid planner and the Regulated Pure Pursuit controller. In `maze.wbt`:

```bash
ros2 launch cobra_flex sim.launch.py publish_tf:=false  # EKF publishes odom TF
ros2 launch /ws/examples/slam_nav2_ekf/stack.launch.py
ros2 action send_goal /navigate_to_pose nav2_msgs/action/NavigateToPose \
    "{pose: {header: {frame_id: map},
      pose: {position: {x: 2.0, y: 0.0}, orientation: {w: 1.0}}}}"
```

The goal is 2 m ahead of the start point, along the first corridor.

The real robot has no gyro. Before using the EKF there, remove the `imu0` block from `ekf.yaml` and set the yaw rate (`vyaw`) in `odom0_config` to `true`. Another option is to skip the EKF: start `robot.launch.py slam:=true` and run Nav2 with `nav2_params.yaml`.

## depth_navigation: depth camera demonstration

A demonstration that turns depth images into motion commands on `platform.wbt`. It is not a finished solution: the robot does not stop at the far end of the platform, so stop the nodes with `Ctrl+C` before the edge.

```bash
ros2 launch cobra_flex sim.launch.py
cd /ws/examples/depth_navigation
python3 depth_floor_mask.py &
python3 reactive_navigator_node.py
```

On the real robot, remap the depth topic of the camera driver to `/camera/depth/image_raw` and adjust the parameters of the nodes to the height and tilt of your camera.
