# cobra_ros: Cobra Flex in Webots and on the real robot with the same ROS 2 topics

```
 Webots (laptop)                              Real robot (Raspberry Pi 5)
 webots/worlds, cobra_udp controller          ESP32 chassis, LiDAR, depth camera
        |  UDP 5555 / TCP 5600                    |           |            |
 cobra_flex/webots_bridge               cobra_flex/cobra_base  LiDAR    camera
        |                                         |          driver     driver
        +-----------------+-----------------------+-----------+------------+
                          |
   /cmd_vel  /odom + TF  /scan  /imu  /camera/depth/image_raw  /battery
                          |
            your code, slam_toolbox, Nav2, examples
```

ROS 2 Humble, Python only. Runs in Docker on a laptop (amd64) and on a Raspberry Pi 5 (arm64).

| Path | Contents |
|---|---|
| `src/cobra_flex/cobra_flex/webots_bridge.py` | Webots controller to ROS 2 |
| `src/cobra_flex/cobra_flex/cobra_base.py` | real chassis driver: `/cmd_vel` to `{"T":13}`, feedback to `/odom` and `/battery` |
| `src/cobra_flex/launch/sim.launch.py`, `robot.launch.py` | entry points with sensor transforms and optional SLAM |
| `webots/protos/CobraFlex.proto` | Webots model of Cobra Flex with LiDAR, gyro and RGB-D camera |
| `webots/worlds/` | `maze.wbt`, `platform.wbt`, `check_lidar.wbt` |
| `webots/controllers/cobra_udp/` | controller of the model: drives the robot and streams all sensors |
| `webots/make_maze.py` | generates a new `maze.wbt` |
| `examples/` | code examples |
| `tests/`, `tools/` | automated checks without Webots or a robot (mock Webots API, simulated ESP32), and a check against real Webots |

## Topics and frames

| Topic | Type | Webots | Real robot |
|---|---|---|---|
| `/cmd_vel` (input) | Twist | yes | yes |
| `/odom` and TF `odom -> base_footprint` | Odometry | wheel encoders | wheel distances `odl`, `odr` |
| `/scan` (frame `laser`) | LaserScan | 360 degrees, 360 rays, 12 m | from the LiDAR driver |
| `/imu` (frame `base_link`) | Imu, angular rates only | gyro | none, the firmware has no IMU output |
| `/camera/depth/image_raw` and `camera_info` | Image 16UC1, mm | RGB-D camera of the model | from the camera driver |
| `/battery` | BatteryState | none | yes |

Static transforms: `base_footprint -> base_link -> laser` and `base_link -> camera_link -> camera_depth_optical_frame`.

In both cases the robot receives a stop if `/cmd_vel` is older than 0.5 s. The speed is limited to 0.5 m/s and 2 rad/s (parameters `max_linear` and `max_angular`).

## 1. Build

```bash
docker build -t cobra_ros .
docker run --rm cobra_ros bash /ws/tests/run_tests.sh      # about 1 minute
docker run --rm cobra_ros bash /ws/tests/run_examples.sh   # about 2 minutes
```

The first test command checks the bridge and the chassis driver, the second checks the examples. On a Linux laptop, add RViz with `--build-arg RVIZ=ros-humble-rviz2`. Without Nav2 the image is smaller: `--build-arg NAV2=""`.

## 2. Webots

Webots R2025a runs on the laptop; it does not run on a Raspberry Pi. The worlds in `webots/worlds` already contain the robot with its controller:

| World | Contents |
|---|---|
| `maze.wbt` | maze of 6 x 6 m with the robot in a corner |
| `platform.wbt` | platform of 5.5 x 2.5 m over empty space, for the depth camera |
| `check_lidar.wbt` | one wall 0.5 m to the left of the robot, for the check below |

`python3 webots/make_maze.py --seed N` writes a different maze.

```bash
webots --stdout --stderr cobra_ros/webots/worlds/maze.wbt
```

Linux laptop:

```bash
xhost +local:
docker run -it --rm --network host --name cobra \
    -e DISPLAY -v /tmp/.X11-unix:/tmp/.X11-unix cobra_ros
ros2 launch cobra_flex sim.launch.py slam:=true      # inside the container
```

Windows or macOS with Docker Desktop:

```bash
docker run -it --rm -p 5600:5600 --name cobra cobra_ros
ros2 launch cobra_flex sim.launch.py slam:=true \
    cmd_host:=host.docker.internal                   # inside the container
```

Keyboard control from another terminal:

```bash
docker exec -it cobra bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard
```

Check once: open `check_lidar.wbt`, start `sim.launch.py` and run `python3 /ws/tests/webots_check.py` in the container. The script moves the robot a little and prints PASS or FAIL for the LiDAR orientation, the depth image, driving forward and turning (odometry and gyro).

## 3. Real robot on the Raspberry Pi 5

Power and the USB connection to the chassis are described in the guide.

```bash
docker run -it --rm --network host --privileged -v /dev:/dev \
    --name cobra cobra_ros
ros2 launch cobra_flex robot.launch.py slam:=true \
    laser_x:=0.05 laser_z:=0.15 camera_x:=0.12 camera_z:=0.10
```

Measure the sensor positions on your robot. The default chassis port is `/dev/serial/by-id/usb-1a86_USB_Single_Serial_*` (the CH343 JSON port); another port is set with `port:=...`.

LiDAR driver for LDROBOT LD19, D500 and STL-19P, in a second terminal:

```bash
cd /ws/src
git clone https://github.com/ldrobotSensorTeam/ldlidar_stl_ros2.git
cd /ws && colcon build --packages-select ldlidar_stl_ros2
source install/setup.bash
ros2 run ldlidar_stl_ros2 ldlidar_stl_ros2_node --ros-args \
    -p product_name:=LDLiDAR_LD19 -p topic_name:=scan \
    -p frame_id:=laser -p port_baudrate:=230400 \
    -p laser_scan_dir:=true -p port_name:=/dev/serial/by-id/<lidar>
```

Start the node directly: its `ld19.launch.py` adds its own transform `base_link -> base_laser`.

Depth camera: for Intel RealSense install `ros-humble-realsense2-camera` and start `ros2 launch realsense2_camera rs_launch.py`. Remap its depth topic to `/camera/depth/image_raw` if your code expects this name, and pass `camera_frame:=camera_link` to match its frames.

Odometry calibration: the robot has skid steering, so the wheels slip in turns and the heading from the wheels is too large. Turn the robot in place by exactly 360 degrees, compare with the yaw in `/odom` and adjust `odom_track_width` in proportion. If `/odom` shows more than 360 degrees, increase it. SLAM corrects the remaining error with the LiDAR.

## Parameters

`webots_bridge`:

| Parameter | Default | Meaning |
|---|---|---|
| `proto` | `tcp` | telemetry transport, `tcp` or `udp` |
| `tel_port` | 5600 | telemetry port |
| `cmd_host`, `cmd_port` | 127.0.0.1, 5555 | where commands are sent |
| `cmd_timeout` | 0.5 | seconds after which an old `/cmd_vel` becomes a stop |
| `max_linear`, `max_angular` | 0.5, 2.0 | speed limits |
| `lidar_reverse` | false | reverse the order of the LiDAR rays |
| `depth_hfov` | 1.518 | field of view of the camera, for `camera_info` |
| `publish_tf` | true | publish the transform `odom -> base_footprint` |

The field of view and range of the LiDAR and the axes of the gyro come from the controller. The environment variables `CMD_HOST`, `CMD_PORT`, `TEL_PORT` and `PROTO` take priority over the parameters.

`cobra_base`: `port`, `baud`, `cmd_rate`, `cmd_timeout`, `max_linear`, `max_angular`, `odom_track_width`, frame names, `publish_tf`.

`cobra_udp` environment variables:

| Variable | Default | Meaning |
|---|---|---|
| `TELEMETRY_HOST`, `TELEMETRY_PORT` | 127.0.0.1, 5600 | where the bridge listens |
| `TELEMETRY_PROTO` | `tcp` | `tcp` or `udp` |
| `CMD_LISTEN_PORT` | 5555 | port for commands |
| `CMD_TIMEOUT` | 0.5 | seconds without commands before a stop |
| `MAX_LINEAR`, `MAX_ANGULAR` | 0.5, 2.0 | speed limits |
| `ODOM_TRACK` | 0.254 | distance between the wheels used for odometry in the simulator |
| `DEPTH_ENABLE`, `DEPTH_EVERY`, `DEPTH_DOWNSAMPLE` | 1, 4, 2 | depth stream: on, every N steps, image reduction |
| `RGB_ENABLE` | 0 | colour image stream |
| `SNAPSHOT` | empty | file name for one image from the robot camera, for debugging |

The controller prints the true pose of the robot and its odometry to the Webots console every 5 seconds.

## Examples

See [examples/README.md](examples/README.md): a minimal obstacle avoidance node, mapping and navigation to a goal with SLAM, Nav2 and EKF, and a depth camera demonstration.
