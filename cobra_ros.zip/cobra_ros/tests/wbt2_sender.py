#!/usr/bin/env python3
"""Imitates the early maze controller: WBT2 (no gyro) over TCP, obeys UDP commands with a
simple unicycle model (the real one keeps the last command; this one too)."""
import math
import socket
import struct
import time

cmd = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
cmd.bind(("0.0.0.0", 5555))
cmd.setblocking(False)
while True:
    try:
        tel = socket.create_connection(("127.0.0.1", 5600), timeout=1)
        break
    except OSError:
        time.sleep(0.3)
x = y = th = v = w = 0.0
dt = 0.032
while True:
    try:
        while True:
            data, _ = cmd.recvfrom(64)
            v, w = struct.unpack("<2f", data[:8])
    except BlockingIOError:
        pass
    x += v * math.cos(th) * dt
    y += v * math.sin(th) * dt
    th += w * dt
    ranges = [3.0] * 180 + [1.0] * 180
    p = b"WBT2" + struct.pack("<6fI", x, y, th, v, 0.0, w, 360) + struct.pack("<360f", *ranges)
    tel.sendall(struct.pack("<I", len(p)) + p)
    time.sleep(dt)
