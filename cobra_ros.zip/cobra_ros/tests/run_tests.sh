#!/bin/bash
# Runs all checks inside the cobra_ros image:
#   docker run --rm cobra_ros bash /ws/tests/run_tests.sh
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
cd /ws
rc=0
MOCK="env PYTHONPATH=/ws/tools/mock_webots python3 /ws/webots/controllers/cobra_udp/cobra_udp.py"

run() {  # name, launch command, simulator command, check mode
  echo "===== $1"
  $3 > /tmp/$1_sim.log 2>&1 &
  S=$!
  sleep 1
  $2 > /tmp/$1_launch.log 2>&1 &
  L=$!
  python3 /ws/tests/checks.py $4 || rc=1
  kill $S 2>/dev/null; kill -INT $L 2>/dev/null; sleep 2; kill $L 2>/dev/null
  pkill -f "cobra_udp.py|wbt2_sender.py|fake_esp32.py|webots_bridge|cobra_base|static_transform" 2>/dev/null
  sleep 1; wait 2>/dev/null
  grep -E "WARN|ERROR" /tmp/$1_launch.log | head -5
}

run sim_tcp "ros2 launch cobra_flex sim.launch.py" "$MOCK" sim
run sim_udp "ros2 launch cobra_flex sim.launch.py proto:=udp" "env TELEMETRY_PROTO=udp $MOCK" sim
run wbt2 "ros2 launch cobra_flex sim.launch.py" "python3 /ws/tests/wbt2_sender.py" wbt2
run robot "ros2 launch cobra_flex robot.launch.py port:=/tmp/cobra_esp32" "python3 /ws/tools/fake_esp32.py /tmp/cobra_esp32" robot
echo "===== last commands the fake ESP32 received:"
grep "'T': 13" /tmp/robot_sim.log | tail -3
exit $rc
