#!/usr/bin/env python3
"""One-time check against real Webots with webots/worlds/check_lidar.wbt.

Start the world, start sim.launch.py, then run in the container:
    python3 /ws/tests/webots_check.py

The robot stands at the arena centre facing +x; the only inner wall is 0.5 m to its left.
The robot moves: about 0.3 m forward and a quarter turn to the left.
"""
import math
import sys
import time

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from sensor_msgs.msg import Image, Imu, LaserScan

FAILS = []


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + (f"  ({detail})" if detail else ""), flush=True)
    if not ok:
        FAILS.append(name)


class Probe(Node):
    def __init__(self):
        super().__init__("webots_check")
        self.last = {}
        self.max_wz = 0.0
        for topic, typ in [("scan", LaserScan), ("odom", Odometry), ("camera/depth/image_raw", Image)]:
            self.create_subscription(typ, topic, lambda m, t=topic: self.last.__setitem__(t, m), 10)
        self.create_subscription(Imu, "imu", self.on_imu, 10)
        self.cmd = self.create_publisher(Twist, "cmd_vel", 10)

    def on_imu(self, m):
        self.last["imu"] = m
        if abs(m.angular_velocity.z) > abs(self.max_wz):
            self.max_wz = m.angular_velocity.z

    def spin_for(self, sec, v=None, w=None):
        end = time.monotonic() + sec
        while time.monotonic() < end:
            if v is not None:
                t = Twist()
                t.linear.x, t.angular.z = v, w
                self.cmd.publish(t)
            rclpy.spin_once(self, timeout_sec=0.05)


def yaw(o):
    q = o.pose.pose.orientation
    return math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))


def ray(scan, angle, width=0.1):
    """Median of the valid rays within +-width of an angle (0 = forward, + = left)."""
    vals = sorted(r for i, r in enumerate(scan.ranges)
                  if abs(math.remainder(scan.angle_min + i * scan.angle_increment - angle, 2 * math.pi)) < width
                  and scan.range_min < r < scan.range_max)
    return vals[len(vals) // 2] if vals else math.inf


def main():
    rclpy.init()
    p = Probe()
    p.spin_for(5.0)
    s = p.last.get("scan")
    check("scan received", s is not None)
    if s is None:
        return finish()
    fov = s.angle_max - s.angle_min + s.angle_increment
    check("LiDAR 360 degrees", abs(fov - 2 * math.pi) < 0.05, f"{math.degrees(fov):.0f} deg, {len(s.ranges)} rays")
    left, right, front, back = ray(s, math.pi / 2), ray(s, -math.pi / 2), ray(s, 0), ray(s, math.pi)
    detail = f"left {left:.2f}, right {right:.2f}, front {front:.2f}, back {back:.2f} m"
    check("wall 0.5 m on the left, open on the right", abs(left - 0.5) < 0.1 and right > 2.5, detail)

    d = p.last.get("camera/depth/image_raw")
    check("depth image received", d is not None, f"{d.width}x{d.height} {d.encoding}" if d else "none")
    if d:
        px = [int.from_bytes(bytes(d.data[k:k + 2]), "little") for k in range(0, len(d.data), 2)]
        bottom = px[(d.height - 1) * d.width:]
        check("depth: the floor is seen in the bottom rows", sum(v > 0 for v in bottom) > 0.5 * d.width,
              f"median {sorted(bottom)[len(bottom) // 2]} mm")

    o0 = p.last.get("odom")
    p.spin_for(2.0, v=0.15, w=0.0)
    p.spin_for(1.0)
    o1 = p.last["odom"]
    dx = o1.pose.pose.position.x - o0.pose.pose.position.x
    check("drives forward along +x", 0.15 < dx < 0.6, f"odom dx={dx:.2f} m")
    p.max_wz = 0.0
    p.spin_for(2.5, v=0.0, w=0.8)
    p.spin_for(1.0)
    o2 = p.last["odom"]
    dyaw = math.degrees(math.remainder(yaw(o2) - yaw(o1), 2 * math.pi))
    check("turning left: odometry yaw grows", dyaw > 30, f"{dyaw:.0f} deg")
    check("turning left: gyro z is positive", p.max_wz > 0.3, f"max {p.max_wz:.2f} rad/s")
    return finish()


def finish():
    print("RESULT", "FAIL" if FAILS else "OK", FAILS, flush=True)
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()
