#!/usr/bin/env python3
"""End-to-end checks, run inside the container by tests/run_tests.sh.

python3 checks.py sim     # bridge + cobra_udp on the mock Webots
python3 checks.py wbt2    # bridge + a WBT2 sender (early maze world, no gyro)
python3 checks.py robot   # cobra_base + tools/fake_esp32.py
"""
import math
import sys
import time

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from sensor_msgs.msg import BatteryState, Image, Imu, LaserScan

FAILS = []


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + (f"  ({detail})" if detail else ""), flush=True)
    if not ok:
        FAILS.append(name)


class Probe(Node):
    def __init__(self):
        super().__init__("probe")
        self.last = {}
        for topic, typ in [("odom", Odometry), ("scan", LaserScan), ("imu", Imu),
                           ("camera/depth/image_raw", Image), ("battery", BatteryState)]:
            self.create_subscription(typ, topic, lambda m, t=topic: self.last.__setitem__(t, m), 10)
        self.cmd = self.create_publisher(Twist, "cmd_vel", 10)

    def spin_for(self, sec, v=None, w=None):
        end = time.monotonic() + sec
        while time.monotonic() < end:
            if v is not None:
                t = Twist()
                t.linear.x, t.angular.z = v, w
                self.cmd.publish(t)
            rclpy.spin_once(self, timeout_sec=0.05)


def yaw(o):
    q = o.pose.pose.orientation
    return math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))


def motion(p, want_imu):
    p.spin_for(1.0)
    o0 = p.last.get("odom")
    check("odom published", o0 is not None)
    if o0 is None:
        return
    p.spin_for(3.0, v=0.2, w=0.5)  # forward and turning left
    o1 = p.last["odom"]
    dx = o1.pose.pose.position.x - o0.pose.pose.position.x
    dyaw = yaw(o1) - yaw(o0)
    check("moves forward on +x", dx > 0.1, f"dx={dx:.2f}")
    check("turns left = yaw grows", dyaw > 0.2, f"dyaw={dyaw:.2f}")
    if want_imu:
        imu = p.last.get("imu")
        check("imu yaw rate positive when turning left", imu is not None and imu.angular_velocity.z > 0.1,
              f"wz={imu.angular_velocity.z:.2f}" if imu else "no imu")
    p.spin_for(1.5)  # no commands: the bridge/driver must stop the robot
    a = p.last["odom"].pose.pose.position.x
    p.spin_for(1.0)
    b = p.last["odom"].pose.pose.position.x
    check("stops when /cmd_vel goes quiet", abs(b - a) < 0.01, f"drift={b - a:.3f}")


def main():
    mode = sys.argv[1]
    rclpy.init()
    p = Probe()
    p.spin_for(4.0)
    if mode in ("sim", "wbt2"):
        s = p.last.get("scan")
        check("scan published", s is not None)
        if s:
            n = len(s.ranges)
            at = lambda a: s.ranges[round((a - s.angle_min) / s.angle_increment)]  # noqa: E731
            fov = s.angle_max - s.angle_min + (s.angle_increment if mode == "sim" else 0.0)
            want = 2 * math.pi if mode == "sim" else math.pi / 2
            check(f"scan: {math.degrees(want):.0f} deg, 360 rays", n == 360 and abs(fov - want) < 1e-3,
                  f"n={n} fov={math.degrees(fov):.1f}")
            left, right = at(0.6), at(-0.6)
            check("scan: obstacle on the left is at positive angles", abs(left - 1.0) < 0.01 and abs(right - 3.0) < 0.01,
                  f"left={left:.2f} right={right:.2f}")
    if mode == "sim":
        d = p.last.get("camera/depth/image_raw")
        check("depth image published", d is not None and d.encoding == "16UC1",
              f"{d.width}x{d.height} {d.encoding}" if d else "none")
        if d:
            px = lambda r: int.from_bytes(bytes(d.data[(r * d.width) * 2:(r * d.width) * 2 + 2]), "little")  # noqa
            check("depth values in mm, no-return = 0", 500 < px(d.height // 2) < 3600 and px(d.height - 1) == 0,
                  f"mid={px(d.height // 2)} last={px(d.height - 1)}")
    if mode == "robot":
        b = p.last.get("battery")
        check("battery voltage", b is not None and abs(b.voltage - 11.8) < 0.01, f"{b.voltage if b else None}")
    motion(p, want_imu=(mode == "sim"))
    print("RESULT", "FAIL" if FAILS else "OK", FAILS, flush=True)
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()
