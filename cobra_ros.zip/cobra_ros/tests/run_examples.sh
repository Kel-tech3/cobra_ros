#!/bin/bash
# Checks that the examples run on top of cobra_flex (needs the full image with Nav2):
#   docker run --rm cobra_ros bash /ws/tests/run_examples.sh
source /opt/ros/humble/setup.bash
source /ws/install/setup.bash
MOCK="env PYTHONPATH=/ws/tools/mock_webots python3 /ws/webots/controllers/cobra_udp/cobra_udp.py"
rc=0
ok()   { echo "PASS $1"; }
bad()  { echo "FAIL $1"; rc=1; }
field() { timeout 10 ros2 topic echo "$1" --once --field "$2" 2>/dev/null | head -1; }
cleanup() { pkill -f cobra_udp; pkill -f "ros2 launch"; pkill -f "python3 .*(simple_avoid|depth_floor_mask|reactive_navigator)"; pkill -f "_node"; sleep 3; }

echo "===== simple_avoid"
$MOCK > /tmp/a_sim.log 2>&1 &
ros2 launch cobra_flex sim.launch.py > /tmp/a_launch.log 2>&1 &
sleep 4
python3 /ws/examples/simple_avoid.py > /tmp/a_node.log 2>&1 &
sleep 3
w=$(field /cmd_vel angular.z); v=$(field /cmd_vel linear.x)
echo "cmd_vel: v=$v w=$w (wall is closer on the left -> expect v=0.15, w<0)"
python3 -c "import sys; sys.exit(0 if float('$v')>0.1 and float('$w')<0 else 1)" && ok "simple_avoid steers away from the closer wall" || bad "simple_avoid"
cleanup

echo "===== depth_navigation"
$MOCK > /tmp/d_sim.log 2>&1 &
ros2 launch cobra_flex sim.launch.py > /tmp/d_launch.log 2>&1 &
sleep 4
cd /ws/examples/depth_navigation
python3 depth_floor_mask.py > /tmp/d_mask.log 2>&1 &
python3 reactive_navigator_node.py > /tmp/d_nav.log 2>&1 &
sleep 6
enc=$(field /floor_camera/depth_thresholded encoding); wd=$(field /floor_camera/depth_thresholded width)
[ "$enc" = "mono8" ] && [ "$wd" = "160" ] && ok "floor mask mono8 160 wide" || bad "floor mask ($enc $wd)"
timeout 10 ros2 topic echo /cmd_vel --once > /tmp/d_cmd.txt 2>&1 && ok "navigator publishes /cmd_vel" || bad "navigator /cmd_vel"
grep -i -E "error|traceback" /tmp/d_nav.log /tmp/d_mask.log | head -5
cleanup
cd /ws

echo "===== slam_nav2_ekf"
$MOCK > /tmp/s_sim.log 2>&1 &
ros2 launch cobra_flex sim.launch.py publish_tf:=false > /tmp/s_launch.log 2>&1 &
sleep 3
ros2 launch /ws/examples/slam_nav2_ekf/stack.launch.py > /tmp/s_stack.log 2>&1 &
sleep 25
timeout 10 ros2 topic echo /odometry/filtered --once > /dev/null 2>&1 && ok "EKF /odometry/filtered" || bad "EKF"
timeout 15 ros2 topic echo /map --once --field info.resolution > /dev/null 2>&1 && ok "slam /map" || bad "slam /map"
state=$(timeout 10 ros2 lifecycle get /bt_navigator 2>&1)
echo "bt_navigator: $state"
echo "$state" | grep -q active && ok "Nav2 active" || bad "Nav2 not active"
timeout 20 ros2 action send_goal /navigate_to_pose nav2_msgs/action/NavigateToPose \
  "{pose: {header: {frame_id: map}, pose: {position: {x: 0.5, y: 0.0}, orientation: {w: 1.0}}}}" > /tmp/s_goal.txt 2>&1
grep -q "Goal accepted" /tmp/s_goal.txt && ok "Nav2 accepts a goal" || { bad "goal"; tail -5 /tmp/s_goal.txt; }
grep -E "\[ERROR\]|process has died" /tmp/s_stack.log | head -8
cleanup
exit $rc
